// Run with: npm run check:sqlite  -> proves SQLite works inside the Electron runtime you installed.
const { app } = require('electron');
app.whenReady().then(() => {
  try {
    const { DatabaseSync } = require('node:sqlite');
    const db = new DatabaseSync(':memory:');
    db.exec('CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT)'); db.prepare('INSERT INTO t (v) VALUES (?)').run('ok');
    console.log(`SQLITE OK (node:sqlite) - Electron ${process.versions.electron}, Node ${process.versions.node}, row = ${db.prepare('SELECT v FROM t').get().v}`);
    app.exit(0);
  } catch (e) { console.error('node:sqlite NOT available in this Electron:', e.message, '\nFallback: npm install better-sqlite3 && npx electron-builder install-app-deps'); app.exit(1); }
});
