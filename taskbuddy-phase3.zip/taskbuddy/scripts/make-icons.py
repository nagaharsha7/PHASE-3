"""Regenerates build/icon.png, build/icon.ico and build/tray*.png (needs: pip install pillow). Run: python scripts/make-icons.py"""
from PIL import Image, ImageDraw, ImageFilter
import math, os
S = 1024
def drop(size):
    big = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    cx, top, r = S / 2, S * .06, S * .335
    cy = S * .64
    ang = math.asin(r / (cy - top))  # tangent lines from the apex to the circle
    # build outline: apex -> left tangent -> circle -> right tangent
    tx = r * math.cos(ang); ty = cy - r * math.sin(ang)
    m = Image.new('L', (S, S), 0); d = ImageDraw.Draw(m)
    d.polygon([(cx, top), (cx - tx, ty), (cx + tx, ty)], fill=255)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=255)
    grad = Image.new('RGBA', (S, S))
    px = grad.load()
    for y in range(S):
        for x in range(S):
            dx = (x - S * .38) / (S * .62); dy = (y - S * .38) / (S * .62)
            t = min(1, math.hypot(dx, dy))
            c0, c1, c2 = (213, 243, 255), (60, 170, 240), (10, 86, 173)
            if t < .4: u = t / .4; c = tuple(int(c0[i] + (c1[i] - c0[i]) * u) for i in range(3))
            else: u = (t - .4) / .6; c = tuple(int(c1[i] + (c2[i] - c1[i]) * u) for i in range(3))
            px[x, y] = c + (255,)
    big.paste(grad, (0, 0), m)
    g = ImageDraw.Draw(big)
    # shine
    sh = Image.new('RGBA', (S, S), (0, 0, 0, 0)); sd = ImageDraw.Draw(sh)
    sd.ellipse([S * .30, S * .40, S * .40, S * .62], fill=(255, 255, 255, 140)); big.alpha_composite(sh.rotate(20, center=(S * .35, S * .5)))
    # face
    for ex in (S * .41, S * .59):
        g.ellipse([ex - S * .035, S * .62 - S * .045, ex + S * .035, S * .62 + S * .045], fill=(11, 37, 64, 255))
        g.ellipse([ex + S * .005, S * .60 - S * .012, ex + S * .028, S * .60 + S * .011], fill=(255, 255, 255, 255))
    g.arc([S * .44, S * .66, S * .56, S * .76], 15, 165, fill=(11, 37, 64, 255), width=int(S * .018))
    for ex in (S * .335, S * .665):
        c = Image.new('RGBA', (S, S), (0, 0, 0, 0)); ImageDraw.Draw(c).ellipse([ex - S * .05, S * .70 - S * .03, ex + S * .05, S * .70 + S * .03], fill=(255, 143, 177, 120)); big.alpha_composite(c)
    return big.resize((size, size), Image.LANCZOS)
os.makedirs('build', exist_ok=True)
drop(512).save('build/icon.png'); drop(256).save('build/icon.ico', sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
drop(32).save('build/tray.png'); drop(64).save('build/tray@2x.png')
print('icons written to build/')
