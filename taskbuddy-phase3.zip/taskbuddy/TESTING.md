# Testing TaskBuddy desktop

## What was verified automatically (no Windows required) - `npm run test:all`
* Engine (12 tests, unchanged) + core/SQLite (15 tests): reminder created once at 8:00, YES adds 250 ml once, NO adds 0, double answers rejected, ignored -> pending -> missed after grace, snooze re-announces after the snooze time, 3-hour sleep -> exactly 1 prompt and no flood, multiple tasks, pause / pause-all (no back-fill on resume), restart persistence, localStorage -> SQLite migration once, SQL constraints block double counting.
* Wiring (2 scripts, fake Electron): real `main.js` boots, toast text/silent flag, one character window for several reminders, transparent + frameless + always-on-top options, answers only accepted from the character window, close-to-tray, tray menu items, Pause/Resume, Settings navigation, character disable, auto-hide after ignore (stays pending), toast click re-opens the right reminder, drag position saved, Exit really quits.
* The character UI was rendered in headless Chromium for all 5 states (screenshots checked).

## NOT verified here - you must run these on Windows (the build sandbox has no Windows, no Electron binary, no network)
A real Windows toast, always-on-top over other apps, dragging on your DPI scaling, autostart, sleep/wake, the installer. Do not treat these as working until each box is ticked.

Start with `npm run electron:start`, then Settings > **Send test reminder**. Tick:

| # | Scenario | How | Expect |
|---|---|---|---|
| 1 | Dashboard open, reminder fires | Create a "Specific times" task 2 min ahead | Toast + character appear |
| 2 | Dashboard minimized | Minimize, wait | Toast + character |
| 3 | Closed to tray | Click X, wait | Toast + character; tray icon still there |
| 4 | Other app focused | Work in VS Code / YouTube | Toast above them; character does not steal typing focus |
| 5 | YES | Click YES, I DID! | Success animation, dashboard total +250 ml |
| 6 | NO | Click NO, NOT YET | Understanding face, no ml added |
| 7 | Ignore | Do nothing 15 s | Character hides; dashboard shows Pending, later Missed |
| 8 | Snooze | Click "Remind me in N min" | Sleeping face; toast + character again after N min |
| 9 | Multiple | Two tasks at the same minute | 2 toasts, ONE character window, "+1 more waiting" |
| 10 | Restart app | Exit via tray, relaunch | Data intact; no duplicate/answered reminders |
| 11 | Restart Windows | Enable "Launch at startup" (installed app), reboot | App in tray, reminders continue |
| 12 | Sleep/wake | Sleep 20+ min, wake | At most the current slot prompts; older ones appear as Missed |
| 13 | Drag | Drag character, trigger another | Reappears at the dragged spot (also after restart) |
| 14 | Disable | Settings > Animated character off | No character; toasts continue |
| 15 | Exit | Tray > Exit TaskBuddy | Process gone (Task Manager), no more toasts |

If a toast does not appear: check Windows Settings > System > Notifications (TaskBuddy / Electron allowed, Focus Assist off) and read `%APPDATA%\TaskBuddy\logs\taskbuddy.log` ("notification shown" / "FAILED").
