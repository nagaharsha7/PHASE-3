// Dashboard preload: the ONLY bridge between the React app and Node/SQLite. Sandboxed, context-isolated, no raw ipcRenderer exposed.
const { contextBridge, ipcRenderer } = require('electron');
const listen = (channel, cb) => { const h = (_e, v) => cb(v); ipcRenderer.on(channel, h); return () => ipcRenderer.removeListener(channel, h); };
contextBridge.exposeInMainWorld('taskbuddy', {
  boot: (legacy) => ipcRenderer.invoke('tb:boot', legacy ?? null),
  action: (name, payload) => ipcRenderer.invoke('tb:action', name, payload),
  onState: (cb) => listen('tb:state', cb),
  onNavigate: (cb) => listen('tb:navigate', cb),
  getInfo: () => ipcRenderer.invoke('tb:info'),
  sendTestReminder: () => ipcRenderer.invoke('tb:test'),
});
