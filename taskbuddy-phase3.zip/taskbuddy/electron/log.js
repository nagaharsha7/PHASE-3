import fs from 'node:fs';
import path from 'node:path';
// Tiny file logger: %APPDATA%\TaskBuddy\logs\taskbuddy.log (rotates at 1 MB). Useful for checking that toasts were really sent.
export function createLogger(dir) {
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, 'taskbuddy.log');
  try { if (fs.statSync(file).size > 1e6) fs.renameSync(file, file + '.old'); } catch { /* first run */ }
  const log = (...a) => { const line = `${new Date().toISOString()} ${a.join(' ')}\n`; try { fs.appendFileSync(file, line); } catch { /* ignore */ } if (!log.quiet) console.log(line.trim()); };
  log.file = file; return log;
}
