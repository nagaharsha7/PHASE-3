// Native Windows toast notifications (Electron's Notification API -> Windows notification centre).
// NOTE: Windows toast action buttons (YES/NO) from Electron need toastXml + COM activation and are not reliable across
// installs, so by design a click on the toast opens the character window, where YES / NO / Later are real buttons.
import { Notification } from 'electron';
import { notificationText } from './messages.js';

export function createNotifier({ iconPath, log, onClick }) {
  const live = new Map(); // keep references alive, otherwise the toast can be garbage-collected and never fire 'click'
  return {
    supported: () => Notification.isSupported(),
    show(l, task, settings, { test = false } = {}) {
      if (!Notification.isSupported()) { log('notification: NOT supported on this system'); return false; }
      const { title, body } = notificationText(l, task);
      const n = new Notification({ title, body, icon: iconPath, silent: !(settings.sound && task?.sound !== false), urgency: 'normal' });
      live.set(l.id, n);
      n.on('click', () => { log(`notification clicked: ${l.id}`); live.delete(l.id); onClick(l.id); });
      n.on('close', () => live.delete(l.id));
      n.on('failed', (_e, err) => { log(`notification FAILED: ${err}`); live.delete(l.id); });
      n.on('show', () => log(`notification shown: ${l.id}${test ? ' (test)' : ''}`));
      n.show(); log(`notification sent: ${l.id} silent=${!(settings.sound && task?.sound !== false)}`);
      return true;
    },
    close(id) { live.get(id)?.close(); live.delete(id); },
  };
}
