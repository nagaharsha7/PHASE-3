// Character-window preload: five narrow calls, nothing else.
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('characterApi', {
  ready: () => ipcRenderer.invoke('ch:ready'),
  answer: (id, status) => ipcRenderer.invoke('ch:answer', { id, status }),
  close: () => ipcRenderer.invoke('ch:close'),
  onShow: (cb) => { ipcRenderer.on('ch:show', (_e, p) => cb(p)); },
});
