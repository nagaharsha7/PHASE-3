// TaskBuddy desktop app - Electron main process.
//  * owns SQLite + the reminder engine (keeps running with the dashboard closed)
//  * native Windows toasts, floating character window, system tray, autostart, single instance
import { app, BrowserWindow, ipcMain, dialog, powerMonitor, shell, Menu } from 'electron';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDatabase } from './db.js';
import { Core } from './core.js';
import { createLogger } from './log.js';
import { createNotifier } from './notifier.js';
import { createCharacter } from './characterWindow.js';
import { createTray } from './tray.js';

const here = path.dirname(fileURLToPath(import.meta.url)), root = path.join(here, '..');
const APP_ID = 'com.taskbuddy.app'; // must equal build.appId in package.json so toasts are attributed to the installed app
const DEV_URL = process.env.ELECTRON_START_URL || '';
const TICK_MS = 5000;
// Toast/tray/window icons must be real files on disk (not inside app.asar), so packaged builds read them from app.asar.unpacked.
const asset = (f) => path.join(root, 'build', f).replace(`app.asar${path.sep}`, `app.asar.unpacked${path.sep}`);

// Windows needs an AppUserModelID for toast notifications. Installed app: appId. `npm run electron:dev`: electron.exe path.
app.setAppUserModelId(app.isPackaged ? APP_ID : process.execPath);

if (!app.requestSingleInstanceLock()) app.quit();

let win = null, core = null, db = null, tray = null, character = null, notifier = null, timer = null, quitting = false, log = console.log;

// ---------- dashboard window ----------
const hiddenLaunch = () => process.argv.includes('--autostart') && core?.state?.settings.startMinimized;

function createWindow() {
  win = new BrowserWindow({
    width: 1120, height: 780, minWidth: 760, minHeight: 560, show: false, title: 'TaskBuddy', backgroundColor: '#0f172a', autoHideMenuBar: true, icon: asset('icon.png'),
    webPreferences: { preload: path.join(here, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true, spellcheck: false },
  });
  if (app.isPackaged) Menu.setApplicationMenu(null);
  win.once('ready-to-show', () => { if (!hiddenLaunch()) win.show(); });
  // Closing the dashboard hides it to the tray; reminders keep running. Only "Exit TaskBuddy" (tray) really quits.
  win.on('close', (e) => { if (!quitting) { e.preventDefault(); win.hide(); trayHint(); log('dashboard closed to tray'); } });
  win.on('minimize', () => { if (core.state?.settings.minimizeToTray) { win.hide(); log('dashboard minimized to tray'); } });
  win.on('session-end', () => { quitting = true; }); // Windows shutdown / log-off must not be blocked by our close handler
  // The dashboard is a local app: never let it navigate away or open windows; external links go to the default browser.
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:\/\//.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file://') && !(DEV_URL && url.startsWith(DEV_URL))) { e.preventDefault(); if (/^https?:\/\//.test(url)) shell.openExternal(url); } });
  if (DEV_URL) win.loadURL(DEV_URL); else win.loadFile(path.join(root, 'dist', 'index.html'));
}
function showDashboard(route) {
  if (!win || win.isDestroyed()) createWindow();
  if (win.isMinimized()) win.restore();
  win.show(); win.focus();
  if (route) win.webContents.send('tb:navigate', route);
}
function trayHint() {
  if (db.getMeta('tray_hint', false)) return;
  db.setMeta('tray_hint', true); tray?.balloon('TaskBuddy is still running', 'Reminders keep working from the system tray. Right-click the icon to exit.');
}

// ---------- reminders -> toast + character ----------
function onDue(logs) {
  const s = core.state.settings;
  for (const l of logs) {
    const task = core.taskOf(l);
    if (s.notifications) notifier.show(l, task, s);
  }
  if (s.character) character.onDue(logs);
}

function applySystemSettings(s, prev) {
  if (!prev || prev.launchAtStartup !== s.launchAtStartup) {
    if (app.isPackaged) app.setLoginItemSettings({ openAtLogin: !!s.launchAtStartup, args: ['--autostart'] });
    else log(`launchAtStartup=${s.launchAtStartup} (only applied by the installed app, not in dev)`);
  }
  tray?.update({ pausedAll: !!s.pausedAll, characterEnabled: !!s.character }); tray?.setPaused(!!s.pausedAll);
}

// ---------- IPC (dashboard only) ----------
function fromDashboard(e) { return win && !win.isDestroyed() && e.sender === win.webContents; }
function registerIpc() {
  ipcMain.handle('tb:boot', (e, legacy) => { if (!fromDashboard(e)) throw new Error('forbidden'); return core.boot(legacy && typeof legacy === 'object' ? legacy : null); });
  ipcMain.handle('tb:action', (e, name, payload) => { if (!fromDashboard(e)) throw new Error('forbidden'); return core.dispatch(name, payload); });
  ipcMain.handle('tb:info', (e) => { if (!fromDashboard(e)) throw new Error('forbidden'); return { version: app.getVersion(), packaged: app.isPackaged, sqlite: db.driver, dbPath: path.join(app.getPath('userData'), 'taskbuddy.db'), logPath: log.file, toastsSupported: notifier.supported(), electron: process.versions.electron }; });
  ipcMain.handle('tb:test', (e) => {
    if (!fromDashboard(e)) throw new Error('forbidden');
    const s = core.state.settings, l = character.showTest();
    if (s.notifications) notifier.show({ ...l, taskName: 'Drink Water' }, { description: 'This is a test reminder.', quantity: 250, unit: 'ml', sound: true }, s, { test: true });
    return { toast: s.notifications && notifier.supported(), character: true };
  });
}

// ---------- scheduler ----------
function startScheduler() {
  timer = setInterval(() => { try { if (core.state) core.tick(); } catch (err) { log('tick error', err.stack || err); } }, TICK_MS);
  const wake = (why) => () => { log(`power event: ${why}`); setTimeout(() => core.state && core.tick(), 1500); };
  powerMonitor.on('resume', wake('resume from sleep')); powerMonitor.on('unlock-screen', wake('unlock'));
  powerMonitor.on('suspend', () => log('power event: suspend'));
}

// ---------- startup ----------
app.on('second-instance', () => showDashboard());
app.on('window-all-closed', () => { /* stay alive in the tray */ });
app.on('before-quit', () => { quitting = true; });
app.on('will-quit', () => { clearInterval(timer); character?.destroy(); try { db?.close(); } catch { /* ignore */ } });

app.whenReady().then(() => {
  log = createLogger(path.join(app.getPath('userData'), 'logs'));
  try { db = openDatabase(path.join(app.getPath('userData'), 'taskbuddy.db')); }
  catch (err) { dialog.showErrorBox('TaskBuddy cannot open its database', String(err.message || err)); app.exit(1); return; }
  log(`start v${app.getVersion()} electron ${process.versions.electron} sqlite=${db.driver} packaged=${app.isPackaged}`);

  core = new Core({ db, log });
  notifier = createNotifier({ iconPath: asset('icon.png'), log, onClick: (id) => character.show(id) });
  character = createCharacter({ core, db, files: { preload: path.join(here, 'preload-character.cjs'), html: path.join(here, 'character', 'index.html') }, log });
  core.on('due', onDue);
  core.on('booted', (s) => applySystemSettings(s.settings, null));
  core.on('state', (s, prev) => { if (win && !win.isDestroyed()) win.webContents.send('tb:state', s); applySystemSettings(s.settings, prev?.settings); character.sync(prev); });

  tray = createTray({ iconPath: asset('tray.png'), handlers: {
    open: () => showDashboard(), settings: () => showDashboard('/settings'), showCharacter: () => character.show(),
    pauseAll: () => core.dispatch('setPausedAll', true), resumeAll: () => core.dispatch('setPausedAll', false),
    exit: () => { log('exit requested from tray'); quitting = true; app.quit(); },
  } });
  tray.update({ pausedAll: false, characterEnabled: true });
  registerIpc(); createWindow(); startScheduler();
  // (Registered last so the first tick's 'due' events - e.g. app started while a reminder is pending - reach the handlers above.)
  // First run: wait for the dashboard to hand over any old localStorage data (tb:boot), then migrate it into SQLite.
  // Normal runs: boot immediately so reminders work even if the dashboard never opens. Fallback after 20 s if the dashboard cannot load.
  if (db.getMeta('migrated', false)) core.boot(null); else setTimeout(() => { if (!core.state) { log('dashboard did not boot in time - starting fresh'); core.boot(null); } }, 20000);
});
