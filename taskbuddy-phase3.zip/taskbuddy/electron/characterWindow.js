// The floating, transparent, always-on-top desktop character. A separate BrowserWindow (not part of the React dashboard).
import { BrowserWindow, screen, ipcMain } from 'electron';

const SIZES = { small: { w: 270, h: 350, px: 13 }, medium: { w: 330, h: 430, px: 16 }, large: { w: 390, h: 510, px: 19 } };
const HIDE_AFTER_MS = Number(process.env.TASKBUDDY_HIDE_MS) || 15000, FEEDBACK_MS = 2800, MARGIN = 16; // env override exists for the automated wiring test only

export function createCharacter({ core, db, files, log }) {
  let win = null, loaded = false, payload = null, deadline = 0, poll = null, feedbackUntil = 0, preferred = null, current = null, programmatic = false;
  const dismissed = new Set(); // reminders the user closed / ignored: they stay pending, the popup just doesn't come back by itself
  const keyOf = (l) => `${l.id}|${l.dueAt}`;
  const settings = () => core.state.settings;
  const size = () => SIZES[settings().characterSize] || SIZES.medium;
  const eligible = (l) => settings().character && (settings().showCharacterForEvery || core.taskOf(l)?.character !== false);
  const queue = () => core.pendingQueue().filter((l) => eligible(l) && !dismissed.has(keyOf(l)))
    .sort((a, b) => (a.id === preferred ? -1 : b.id === preferred ? 1 : 0));
  const alive = () => win && !win.isDestroyed();

  function place() {
    const { w, h } = size(), saved = db.getCharacter('position', null);
    if (saved) { // only trust a remembered spot if it is still on a connected display
      const d = screen.getDisplayNearestPoint({ x: saved.x + w / 2, y: saved.y + h / 2 }).workArea;
      const x = Math.min(Math.max(saved.x, d.x), d.x + d.width - w), y = Math.min(Math.max(saved.y, d.y), d.y + d.height - h);
      return { x, y };
    }
    const a = screen.getPrimaryDisplay().workArea, [v, hz] = (settings().characterPosition || 'bottom-right').split('-');
    return { x: hz === 'left' ? a.x + MARGIN : a.x + a.width - w - MARGIN, y: v === 'top' ? a.y + MARGIN : a.y + a.height - h - MARGIN };
  }
  function move(p) { programmatic = true; win.setBounds({ ...p, width: size().w, height: size().h }); setTimeout(() => { programmatic = false; }, 150); }

  function ensureWindow() {
    if (alive()) return;
    loaded = false;
    win = new BrowserWindow({
      ...place(), width: size().w, height: size().h, show: false, frame: false, transparent: true, backgroundColor: '#00000000',
      resizable: false, maximizable: false, minimizable: false, fullscreenable: false, skipTaskbar: true, alwaysOnTop: true, hasShadow: false, title: 'TaskBuddy Character',
      webPreferences: { preload: files.preload, contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false, autoplayPolicy: 'no-user-gesture-required', spellcheck: false },
    });
    win.setAlwaysOnTop(true, 'screen-saver'); // above normal windows, incl. full-screen video players where Windows allows it
    win.setMenu(null);
    win.webContents.on('will-navigate', (e) => e.preventDefault());
    win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    win.on('moved', () => { if (!programmatic && alive()) { const [x, y] = win.getPosition(); db.setCharacter('position', { x, y }); log(`character moved to ${x},${y}`); } });
    win.on('closed', () => { win = null; loaded = false; stopPoll(); });
    win.loadFile(files.html);
  }

  function send() { if (alive() && loaded && payload) win.webContents.send('ch:show', payload); }

  function startPoll() { // auto-hide countdown; pauses while the pointer is over the character (drag regions swallow DOM hover events, so poll the cursor)
    if (poll) return;
    poll = setInterval(() => {
      if (!alive() || !win.isVisible()) return stopPoll();
      const now = Date.now(), c = screen.getCursorScreenPoint(), b = win.getBounds();
      if (c.x >= b.x && c.x <= b.x + b.width && c.y >= b.y && c.y <= b.y + b.height) deadline = Math.max(deadline, now + HIDE_AFTER_MS);
      if (now < feedbackUntil) return;
      if (now >= deadline) { ignoreAll('auto-hidden after being ignored'); }
    }, 400);
  }
  function stopPoll() { clearInterval(poll); poll = null; }
  // Everything currently queued is dismissed (not answered): it stays `pending` and turns `missed` after the grace period.
  function ignoreAll(why) { const q = queue(); q.forEach((l) => dismissed.add(keyOf(l))); if (current) dismissed.add(keyOf(current)); log(`character ${why}: ${q.length || 1} reminder(s) stay pending`); hide(); }
  function hide() { stopPoll(); current = null; if (alive()) win.hide(); }

  // Shows (or updates) the one character window with the first eligible reminder.
  function render({ rearm = false, idle = false } = {}) {
    const q = queue();
    if (!q.length && !idle) return hide();
    const l = q[0] || null, task = l && core.taskOf(l), sz = size(), s = settings();
    const changed = !current || !l || current.id !== l.id || current.dueAt !== l.dueAt;
    current = l;
    payload = { kind: l ? 'reminder' : 'idle', id: l?.id, taskName: l?.taskName, description: task?.description || '', quantity: l?.quantity || task?.quantity || 0, unit: l?.unit || task?.unit || '', scheduledTime: l?.scheduledTime, more: Math.max(0, q.length - 1),
      animations: s.characterAnimations !== false, fontPx: sz.px, snoozeMinutes: s.snoozeMinutes, hideAfterMs: HIDE_AFTER_MS, chime: !!(s.sound && !s.notifications && l && changed) };
    ensureWindow();
    if (win.getSize()[0] !== sz.w || win.getSize()[1] !== sz.h) move(place());
    if (rearm || changed || !win.isVisible()) deadline = Date.now() + HIDE_AFTER_MS;
    send();
    if (!win.isVisible()) win.showInactive(); // never steal keyboard focus from VS Code / the browser
    win.moveTop(); startPoll();
  }

  // ---- IPC (only accepted from this window) ----
  const fromMe = (e) => alive() && e.sender === win.webContents;
  ipcMain.handle('ch:ready', (e) => { if (!fromMe(e)) return; loaded = true; send(); });
  ipcMain.handle('ch:close', (e) => { if (!fromMe(e)) return; ignoreAll('closed by user'); });
  ipcMain.handle('ch:answer', (e, { id, status } = {}) => {
    if (!fromMe(e)) return { ok: false, reason: 'forbidden' };
    let res;
    if (typeof id === 'string' && id.startsWith('test|')) res = { ok: true, status: status === 'snoozed' ? 'snoozed' : status, quantity: status === 'completed' ? 250 : 0, unit: 'ml', taskName: 'Test reminder', snoozeMinutes: settings().snoozeMinutes, test: true };
    else res = core.respond(id, status);
    log(`character answer ${id} -> ${status}: ${res.ok ? 'ok' : res.reason}`);
    feedbackUntil = Date.now() + FEEDBACK_MS;
    setTimeout(() => { feedbackUntil = 0; preferred = null; if (String(id).startsWith('test|')) hide(); else render({ rearm: true }); }, FEEDBACK_MS);
    return res;
  });

  return {
    isVisible: () => alive() && win.isVisible(),
    // New reminder(s) became due: always show unless the user turned the character off.
    onDue(logs) { if (logs.some(eligible)) { log(`character: ${logs.length} new reminder(s)`); render({ rearm: true }); } },
    // Tray "Show Character" / toast click: bring back anything the user dismissed.
    show(id) { dismissed.clear(); preferred = id || null; render({ rearm: true, idle: true }); },
    showTest() {
      const l = { id: `test|${Date.now()}`, taskName: 'Drink Water', quantity: 250, unit: 'ml', scheduledTime: new Date().toTimeString().slice(0, 5), dueAt: Date.now() };
      ensureWindow(); current = null;
      payload = { kind: 'reminder', id: l.id, taskName: l.taskName, description: 'This is a test reminder.', quantity: 250, unit: 'ml', scheduledTime: l.scheduledTime, more: 0, animations: settings().characterAnimations !== false, fontPx: size().px, snoozeMinutes: settings().snoozeMinutes, hideAfterMs: HIDE_AFTER_MS, chime: !!(settings().sound && !settings().notifications) };
      deadline = Date.now() + HIDE_AFTER_MS; send(); if (!win.isVisible()) win.showInactive(); win.moveTop(); startPoll(); return l;
    },
    // Called on every state change: keeps the popup in sync (answered elsewhere, settings changed, character disabled...).
    sync(prev) {
      const s = settings();
      if (!s.character) { if (alive() && win.isVisible()) hide(); return; }
      if (prev && prev.settings.characterPosition !== s.characterPosition) { db.delCharacter('position'); if (alive()) move(place()); }
      if (!alive() || !win.isVisible() || Date.now() < feedbackUntil) return;
      if (payload?.kind === 'reminder' && !String(payload.id).startsWith('test|')) {
        const still = core.state.logs[payload.id]?.status === 'pending';
        if (!still || prev?.settings.characterSize !== s.characterSize || prev?.settings.characterAnimations !== s.characterAnimations) render();
      }
    },
    resetPosition() { db.delCharacter('position'); if (alive()) move(place()); },
    destroy() { stopPoll(); if (alive()) win.destroy(); },
  };
}
