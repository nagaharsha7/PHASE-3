// Floating character UI. Plain DOM + textContent only (task names come from the user: never inserted as HTML).
const api = window.characterApi;
const $ = (id) => document.getElementById(id);
const app = $('app'), title = $('title'), text = $('text'), meta = $('meta'), buttons = $('buttons'), later = $('later');
let cur = null, locked = false;

const isWater = (n) => /water|hydrat/i.test(n || '');
const amount = (p) => (p.quantity ? `${p.quantity}${p.unit ? ' ' + p.unit : ''}` : '');
const due = (t) => { if (!t) return ''; const [h, m] = t.split(':').map(Number); return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };
const state = (s) => { app.dataset.state = s; };
const say = (t, x, m = '') => { title.textContent = t; text.textContent = x; meta.textContent = m; };
const show = (el, on) => el.classList.toggle('hidden', !on);

function chime() { // optional sound when no Windows toast is playing its own
  try { const ctx = new AudioContext(); [660, 880].forEach((f, i) => { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.value = f; o.connect(g); g.connect(ctx.destination); const t = ctx.currentTime + i * .16; g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(.18, t + .02); g.gain.exponentialRampToValueAtTime(.0001, t + .3); o.start(t); o.stop(t + .32); }); } catch { /* audio unavailable */ }
}

function render(p) {
  cur = p; locked = false;
  document.documentElement.style.fontSize = `${p.fontPx}px`;
  app.classList.toggle('noanim', !p.animations);
  if (p.chime) chime();
  if (p.kind === 'idle') { state('idle'); say('Hi! 👋', "You're all caught up. I'll pop up when it's time!"); show(buttons, false); show(later, false); return; }
  state('reminder');
  const a = amount(p);
  if (isWater(p.taskName)) say('Hey! 👋 Time to drink water!', a ? `Did you drink your ${a}?` : 'Did you have some water?', p.description);
  else say(`Hey! 👋 Time for ${p.taskName}!`, `Did you complete it${a ? ` (${a})` : ''}?`, [p.description, p.scheduledTime && `Due ${due(p.scheduledTime)}`].filter(Boolean).join(' · '));
  if (p.more) meta.textContent = [meta.textContent, `+${p.more} more waiting`].filter(Boolean).join(' · ');
  show(buttons, true); show(later, true); $('yes').disabled = $('no').disabled = later.disabled = false;
  later.textContent = `💤 Remind me in ${p.snoozeMinutes} min`;
}

async function answer(status) {
  if (locked || !cur || cur.kind !== 'reminder') return;
  locked = true; $('yes').disabled = $('no').disabled = later.disabled = true; // one answer per reminder, no double clicks
  let res; try { res = await api.answer(cur.id, status); } catch { res = { ok: false, reason: 'error' }; }
  show(buttons, false); show(later, false);
  if (!res.ok) { state('idle'); say('Already handled ✅', res.reason === 'error' ? 'Something went wrong. Please use the dashboard.' : 'That reminder was already answered.'); return; }
  const a = res.quantity ? `${res.quantity}${res.unit ? ' ' + res.unit : ''}` : '';
  if (status === 'completed') { state('success'); say(isWater(res.taskName) ? `Awesome! 💧 I've recorded ${a || 'it'}!` : `Awesome! 🎉 I've recorded ${res.taskName}${a ? ` (${a})` : ''}!`, 'Great job, keep it up!'); }
  else if (status === 'not_completed') { state('notdone'); say("That's okay! 🫶", "I've noted it. See you next time!"); }
  else { state('snooze'); say('Zzz… 💤', `I'll remind you again in ${res.snoozeMinutes} min.`); }
}

$('yes').addEventListener('click', () => answer('completed'));
$('no').addEventListener('click', () => answer('not_completed'));
later.addEventListener('click', () => answer('snoozed'));
$('close').addEventListener('click', () => api.close());
api.onShow(render);
api.ready();
