// SQLite storage for the main process. Only main.js/core.js touch this; the React app reaches data through IPC.
// Driver: Node's built-in `node:sqlite` (ships inside Electron's Node, no native build needed). If that is missing,
// falls back to `better-sqlite3` when it has been installed. Both expose prepare()/exec()/run()/get()/all(), which is all we use.
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);

function loadDriver() {
  const errs = [];
  try { const { DatabaseSync } = require('node:sqlite'); return { name: 'node:sqlite', open: (f) => new DatabaseSync(f) }; } catch (e) { errs.push(`node:sqlite: ${e.message}`); }
  try { const D = require('better-sqlite3'); return { name: 'better-sqlite3', open: (f) => new D(f) }; } catch (e) { errs.push(`better-sqlite3: ${e.message}`); }
  throw new Error(`No SQLite driver is available.\n${errs.join('\n')}\nFix: run "npm install better-sqlite3" then "npx electron-builder install-app-deps".`);
}

const SCHEMA = `
CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY, position INTEGER NOT NULL, name TEXT NOT NULL, paused INTEGER NOT NULL DEFAULT 0 CHECK (paused IN (0,1)),
  data TEXT NOT NULL, updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reminder_logs (
  id TEXT PRIMARY KEY,                                   -- taskId|date|time : one row per scheduled slot, ever
  task_id TEXT NOT NULL, task_name TEXT NOT NULL, date TEXT NOT NULL, scheduled_time TEXT NOT NULL,
  scheduled_at INTEGER NOT NULL, due_at INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending','snoozed','completed','not_completed','missed')),
  response_time TEXT, quantity REAL NOT NULL DEFAULT 0 CHECK (quantity >= 0), unit TEXT NOT NULL DEFAULT '',
  snooze_until INTEGER, snooze_count INTEGER NOT NULL DEFAULT 0,
  UNIQUE (task_id, date, scheduled_time)
);
CREATE INDEX IF NOT EXISTS idx_logs_date ON reminder_logs (date);
CREATE INDEX IF NOT EXISTS idx_logs_status ON reminder_logs (status);
-- An answered reminder can never be changed to another status (no double counting, even from raw SQL).
CREATE TRIGGER IF NOT EXISTS trg_final_status BEFORE UPDATE OF status ON reminder_logs
  WHEN OLD.status IN ('completed','not_completed','missed') AND NEW.status <> OLD.status
  BEGIN SELECT RAISE(ABORT, 'reminder already finalised'); END;
CREATE TABLE IF NOT EXISTS daily_summaries (date TEXT PRIMARY KEY, data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS character_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
`;

const rowToLog = (r) => ({ id: r.id, taskId: r.task_id, taskName: r.task_name, date: r.date, scheduledTime: r.scheduled_time, scheduledAt: r.scheduled_at, dueAt: r.due_at, responseTime: r.response_time, status: r.status, quantity: r.quantity, unit: r.unit, snoozeUntil: r.snooze_until, snoozeCount: r.snooze_count });
const UPSERT_LOG = `INSERT INTO reminder_logs (id,task_id,task_name,date,scheduled_time,scheduled_at,due_at,status,response_time,quantity,unit,snooze_until,snooze_count)
  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
  ON CONFLICT(id) DO UPDATE SET task_name=excluded.task_name, due_at=excluded.due_at, status=excluded.status, response_time=excluded.response_time,
    quantity=excluded.quantity, snooze_until=excluded.snooze_until, snooze_count=excluded.snooze_count
  WHERE reminder_logs.status IN ('pending','snoozed')`; // finalised rows are immutable
const logArgs = (l) => [l.id, l.taskId, l.taskName ?? '', l.date, l.scheduledTime, l.scheduledAt, l.dueAt, l.status, l.responseTime ?? null, l.quantity ?? 0, l.unit ?? '', l.snoozeUntil ?? null, l.snoozeCount ?? 0];

export function openDatabase(file) {
  const driver = loadDriver(), raw = driver.open(file);
  raw.exec('PRAGMA journal_mode = WAL; PRAGMA synchronous = NORMAL; PRAGMA foreign_keys = ON;');
  raw.exec(SCHEMA);
  const q = (sql) => raw.prepare(sql);
  const tx = (fn) => { raw.exec('BEGIN IMMEDIATE'); try { const r = fn(); raw.exec('COMMIT'); return r; } catch (e) { try { raw.exec('ROLLBACK'); } catch { /* already rolled back */ } throw e; } };
  const json = (v) => JSON.stringify(v);
  const sumCache = new Map();

  const kvGet = (table, key, fallback = null) => { const r = q(`SELECT value FROM ${table} WHERE key=?`).get(key); return r ? JSON.parse(r.value) : fallback; };
  const kvSet = (table, key, value) => q(`INSERT INTO ${table} (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value`).run(key, json(value));
  const kvDel = (table, key) => q(`DELETE FROM ${table} WHERE key=?`).run(key);

  function writeTasks(tasks) {
    const keep = tasks.map((t) => t.id), up = q(`INSERT INTO tasks (id,position,name,paused,data,updated_at) VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET position=excluded.position,name=excluded.name,paused=excluded.paused,data=excluded.data,updated_at=excluded.updated_at`);
    for (const r of q('SELECT id FROM tasks').all()) if (!keep.includes(r.id)) q('DELETE FROM tasks WHERE id=?').run(r.id); // reminder_logs are kept
    tasks.forEach((t, i) => up.run(t.id, i, t.name, t.paused ? 1 : 0, json(t), Date.now()));
  }
  function writeSummaries(sums) {
    const up = q('INSERT INTO daily_summaries (date,data) VALUES (?,?) ON CONFLICT(date) DO UPDATE SET data=excluded.data');
    for (const [d, s] of Object.entries(sums)) { const j = json(s); if (sumCache.get(d) !== j) { up.run(d, j); sumCache.set(d, j); } }
  }
  const writeSettings = (prev, next) => { for (const [k, v] of Object.entries(next)) if (!prev || json(prev[k]) !== json(v)) kvSet('settings', k, v); };

  return {
    driver: driver.name,
    raw,
    load() {
      const tasks = q('SELECT data FROM tasks ORDER BY position').all().map((r) => JSON.parse(r.data));
      const logs = {}; for (const r of q('SELECT * FROM reminder_logs').all()) logs[r.id] = rowToLog(r);
      const summaries = {}; for (const r of q('SELECT date,data FROM daily_summaries').all()) { summaries[r.date] = JSON.parse(r.data); sumCache.set(r.date, r.data); }
      const settings = {}; for (const r of q('SELECT key,value FROM settings').all()) settings[r.key] = JSON.parse(r.value);
      return { tasks, logs, summaries, settings };
    },
    // Persist only what changed between two states, in one transaction. Logs keep object identity when unchanged (see engine.js).
    save(prev, next) {
      tx(() => {
        if (!prev || prev.tasks !== next.tasks) writeTasks(next.tasks);
        const up = q(UPSERT_LOG);
        for (const [id, l] of Object.entries(next.logs)) if (!prev || prev.logs[id] !== l) up.run(...logArgs(l));
        writeSummaries(next.summaries);
        if (!prev || prev.settings !== next.settings) writeSettings(prev?.settings, next.settings);
      });
    },
    // Full replace (first-run migration, backup restore).
    replaceAll(state) {
      tx(() => {
        for (const t of ['reminder_logs', 'tasks', 'daily_summaries', 'settings']) q(`DELETE FROM ${t}`).run();
        sumCache.clear();
        writeTasks(state.tasks);
        const ins = q(UPSERT_LOG); for (const l of Object.values(state.logs)) ins.run(...logArgs(l));
        writeSummaries(state.summaries); writeSettings(null, state.settings);
      });
    },
    getMeta: (k, f) => kvGet('meta', k, f), setMeta: (k, v) => kvSet('meta', k, v),
    getCharacter: (k, f) => kvGet('character_settings', k, f), setCharacter: (k, v) => kvSet('character_settings', k, v), delCharacter: (k) => kvDel('character_settings', k),
    close() { try { raw.exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch { /* ignore */ } raw.close(); },
  };
}
