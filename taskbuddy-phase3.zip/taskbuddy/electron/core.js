// Main-process brain: owns the app state, runs the reminder engine on a timer, persists to SQLite, and emits events.
// No Electron imports here, so the whole thing is unit-tested with plain Node (tests/core.test.mjs).
import { EventEmitter } from 'node:events';
import { reconcile, buildSummaries } from '../src/lib/engine.js';
import * as A from '../src/lib/actions.js';
import { DEFAULT_SETTINGS, SEED_TASK } from '../src/lib/defaults.js';

const ACTIONS = new Set(['saveTask', 'togglePause', 'deleteTask', 'respond', 'setSettings', 'importAll', 'setPausedAll']);
const ANSWERS = new Set(['completed', 'not_completed', 'snoozed']);

export class Core extends EventEmitter {
  constructor({ db, clock = () => new Date(), log = () => {} }) {
    super();
    this.db = db; this.clock = clock; this.log = log;
    this.state = null; this.announced = new Set(); this.lastTick = 0;
  }

  // First run: import legacy browser data (if the renderer found any) or seed the sample task. Later runs: load SQLite.
  boot(legacy) {
    if (!this.db.getMeta('migrated', false)) {
      const base = legacy?.tasks ? A.importAll(legacy, this.clock()) : { tasks: [{ ...SEED_TASK, scheduleFrom: this.clock().getTime() }], logs: {}, summaries: {}, settings: { ...DEFAULT_SETTINGS } };
      this.db.replaceAll(base);
      this.db.setMeta('migrated', legacy?.tasks ? 'legacy-import' : 'fresh');
      this.log(`first run: ${legacy?.tasks ? `imported ${legacy.tasks.length} task(s), ${Object.keys(legacy.logs || {}).length} log(s) from localStorage` : 'seeded sample task'}`);
    }
    if (!this.state) { const s = this.db.load(); this.state = { ...s, settings: { ...DEFAULT_SETTINGS, ...s.settings } }; this.emit('booted', this.state); this.tick(); }
    return this.state;
  }

  commit(next) { const prev = this.state; this.db.save(prev, next); this.state = next; this.emit('state', next, prev); }

  // Called every few seconds, after wake/unlock, and after any change. Idempotent.
  tick(now = this.clock()) {
    if (!this.state) return;
    const gap = this.lastTick ? now.getTime() - this.lastTick : 0; this.lastTick = now.getTime();
    if (gap > 90000) this.log(`clock gap of ${Math.round(gap / 1000)}s (sleep/wake?) - recalculating`);
    const s = this.state;
    const eng = s.settings.pausedAll ? s.tasks.map((t) => ({ ...t, paused: true })) : s.tasks;
    const r = reconcile(eng, s.logs, s.settings, now);
    const sums = buildSummaries(r.logs, now);
    if (r.changed || Object.keys(sums).some((k) => !s.summaries[k])) this.commit({ ...s, logs: r.logs, summaries: sums });
    this.announceNew();
    return gap;
  }

  // A reminder is announced once per (id, dueAt). Snooze changes dueAt, so it is announced again when the snooze ends.
  announceNew() {
    if (this.state.settings.pausedAll) return;
    const fresh = [], live = new Set();
    for (const l of Object.values(this.state.logs)) {
      if (l.status !== 'pending') continue;
      const key = `${l.id}|${l.dueAt}`; live.add(key);
      if (!this.announced.has(key) && this.taskOf(l)?.notify !== false && this.taskOf(l)) { this.announced.add(key); fresh.push(l); }
    }
    for (const k of this.announced) if (!live.has(k)) this.announced.delete(k);
    if (fresh.length) this.emit('due', fresh);
  }

  taskOf(l) { return this.state.tasks.find((t) => t.id === l.taskId); }
  pendingQueue() { return Object.values(this.state.logs).filter((l) => l.status === 'pending' && this.taskOf(l) && this.taskOf(l).notify !== false).sort((a, b) => a.dueAt - b.dueAt || a.id.localeCompare(b.id)); }

  // Single entry point for everything the UI can do.
  dispatch(name, payload) {
    if (!ACTIONS.has(name)) throw new Error(`Unknown action: ${name}`);
    const now = this.clock(), s = this.state;
    let next = s;
    switch (name) {
      case 'saveTask': if (typeof payload?.id !== 'string' || typeof payload.name !== 'string') throw new Error('Invalid task'); next = A.saveTask(s, payload, now); break;
      case 'togglePause': next = A.togglePause(s, String(payload), now); break;
      case 'deleteTask': next = A.deleteTask(s, String(payload)); break;
      case 'setPausedAll': next = A.setPausedAll(s, !!payload, now); break;
      case 'setSettings': next = A.setSettings(s, Object.fromEntries(Object.entries(payload || {}).filter(([k]) => k in DEFAULT_SETTINGS))); break;
      case 'importAll': { const imp = A.importAll(payload, now); this.db.replaceAll(imp); const prev = this.state; this.state = imp; this.announced.clear(); this.emit('state', imp, prev); this.tick(); return this.state; }
      case 'respond': this.respond(payload?.id, payload?.status); return this.state; // the dashboard always gets the full state back
      default: break;
    }
    if (next !== s) this.commit(next);
    this.tick(now);
    return this.state;
  }

  // Result tells the caller (character window / dashboard) what happened. Only pending/snoozed reminders can be answered.
  respond(id, status) {
    if (typeof id !== 'string' || !ANSWERS.has(status)) return { ok: false, reason: 'invalid' };
    const before = this.state.logs[id];
    if (!before) return { ok: false, reason: 'unknown' };
    if (before.status !== 'pending' && before.status !== 'snoozed') return { ok: false, reason: 'already-' + before.status };
    const next = A.respond(this.state, id, status, this.clock());
    if (next === this.state) return { ok: false, reason: 'rejected' };
    this.commit(next);
    const l = next.logs[id];
    this.emit('responded', l, status);
    return { ok: true, status: l.status, quantity: l.quantity, unit: l.unit, taskName: l.taskName, snoozeMinutes: this.state.settings.snoozeMinutes };
  }
}
