import { Tray, Menu, nativeImage } from 'electron';

export function createTray({ iconPath, handlers }) {
  const tray = new Tray(nativeImage.createFromPath(iconPath));
  tray.setToolTip('TaskBuddy');
  tray.on('click', handlers.open);
  tray.on('double-click', handlers.open);
  const update = ({ pausedAll, characterEnabled }) => tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Open TaskBuddy', click: handlers.open },
    { label: 'Show Character', click: handlers.showCharacter, enabled: characterEnabled },
    { type: 'separator' },
    { label: 'Pause All Reminders', click: handlers.pauseAll, enabled: !pausedAll },
    { label: 'Resume All Reminders', click: handlers.resumeAll, enabled: pausedAll },
    { type: 'separator' },
    { label: 'Settings', click: handlers.settings },
    { label: 'Exit TaskBuddy', click: handlers.exit },
  ]));
  const setPaused = (p) => tray.setToolTip(p ? 'TaskBuddy (reminders paused)' : 'TaskBuddy');
  return { tray, update, setPaused, balloon: (title, content) => tray.displayBalloon?.({ title, content, iconType: 'info' }) };
}
