// Text shown in the Windows notification (pure, testable).
const isWater = (t) => /water|hydrat/i.test(t || '');
export function notificationText(log, task) {
  const qty = log.quantity || task?.quantity || 0, unit = log.unit || task?.unit || '', name = log.taskName || task?.name || 'Task';
  const amount = qty ? `${qty}${unit ? ' ' + unit : ''}` : '';
  if (isWater(name)) return { title: 'TASKBUDDY 💧', body: ['Time to drink water!', amount ? `You should drink ${amount} of water.` : (task?.description || 'Stay hydrated.')].join('\n') };
  const lines = [`Time for: ${name}`];
  if (task?.description) lines.push(task.description);
  if (amount) lines.push(`Amount: ${amount}`);
  return { title: 'TASKBUDDY 🔔', body: lines.join('\n') };
}
