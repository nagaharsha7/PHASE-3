export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: { extend: {
    fontFamily: { sans: ['"Segoe UI Variable Text"', '"Segoe UI"', 'system-ui', 'sans-serif'], display: ['"Segoe UI Variable Display"', '"Segoe UI"', 'system-ui', 'sans-serif'] },
    colors: { ink: { 50:'#f3f7fb',100:'#e4ecf4',200:'#c9d7e6',500:'#5b7691',700:'#27425c',800:'#14293d',900:'#0b1b2b',950:'#071320' },
              drop: { 400:'#38bdf8',500:'#0ea5e9',600:'#0284c7' } },
    keyframes: { bob:{'0%,100%':{transform:'translateY(0)'},'50%':{transform:'translateY(-6px)'}}, wave:{'0%,100%':{transform:'rotate(0)'},'50%':{transform:'rotate(-25deg)'}}, sway:{'0%,100%':{transform:'rotate(-4deg)'},'50%':{transform:'rotate(4deg)'}} },
    animation: { bob:'bob 2.4s ease-in-out infinite', wave:'wave .7s ease-in-out infinite', sway:'sway 2s ease-in-out infinite' }
  } },
  plugins: []
};
