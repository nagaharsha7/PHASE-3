import assert from 'node:assert/strict';
import * as electron from 'electron';
process.env.TASKBUDDY_HIDE_MS = '1000';
const { rec } = electron;
await import('../../electron/main.js'); await new Promise((r) => setTimeout(r, 200));
const dash = rec.windows[0], call = (c, ...a) => rec.ipc[c]({ sender: dash.webContents }, ...a);
const n = new Date(), hhmm = `${String(n.getHours()).padStart(2, '0')}:${String(n.getMinutes()).padStart(2, '0')}`;
const mk = (id, name) => ({ id, name, description: '', type: 'specific', times: [hhmm], days: [0,1,2,3,4,5,6], date: '', quantity: 0, unit: '', notify: true, character: true, sound: true, paused: false, scheduleFrom: 0, intervalMinutes: 60, start: '08:00', end: '22:00' });
const st = await call('tb:boot', { version: 2, tasks: [mk('a', 'Task A'), mk('b', 'Task B')], logs: {}, settings: {} });
const ch = rec.windows.find((w) => w !== dash);
assert.equal(rec.toasts.length, 2); assert.equal(rec.windows.length, 2, 'multiple reminders => still ONE character window');
await rec.ipc['ch:ready']({ sender: ch.webContents });
assert.equal(ch.webContents.sent.filter(([c]) => c === 'ch:show').at(-1)[1].more, 1);
assert.equal(ch.visible, true);
await new Promise((r) => setTimeout(r, 1900)); // ignore the popup
assert.equal(ch.visible, false, 'auto-hidden when ignored');
const pend = Object.values((await call('tb:action', 'setSettings', {})).logs).filter((l) => l.status === 'pending'); assert.equal(pend.length, 2, 'ignored reminders stay pending');
// tray "Show Character" brings them back; toast click focuses the chosen reminder first
const tray = rec.trayMenus.at(-1); tray.find((m) => m.label === 'Show Character').click(); assert.equal(ch.visible, true);
rec.toasts[1].emit('click'); assert.equal(ch.webContents.sent.filter(([c]) => c === 'ch:show').at(-1)[1].id, rec.toasts[1].o.title && pend.find((l) => l.taskId === 'b').id);
console.log('WIRING TEST 2 OK'); process.exit(0);
