// Lets plain Node import the Electron main process: `import 'electron'` resolves to our recording stub.
import { register } from 'node:module';
register('./loader.mjs', import.meta.url);
