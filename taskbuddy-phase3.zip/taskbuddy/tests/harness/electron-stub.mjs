// Minimal in-memory imitation of the Electron APIs TaskBuddy uses. It records what the app does (toasts, windows, tray menus).
// It proves OUR wiring (handlers, settings, state transitions). It cannot prove Windows itself shows a toast - see TESTING.md.
import { EventEmitter } from 'node:events';
import os from 'node:os'; import fs from 'node:fs'; import path from 'node:path';
export const userData = fs.mkdtempSync(path.join(os.tmpdir(), 'taskbuddy-test-'));
export const rec = { toasts: [], windows: [], trayMenus: [], balloons: [], loginItems: [], ipc: {}, cursor: { x: 0, y: 0 } };
class WC extends EventEmitter { constructor() { super(); this.sent = []; } send(c, p) { this.sent.push([c, p]); } setWindowOpenHandler() {} }
export class BrowserWindow extends EventEmitter {
  constructor(o) { super(); this.o = o; this.visible = false; this.destroyed = false; this.bounds = { x: o.x ?? 0, y: o.y ?? 0, width: o.width, height: o.height }; this.webContents = new WC(); rec.windows.push(this); }
  loadFile(f) { this.file = f; } loadURL(u) { this.url = u; } show() { this.visible = true; } showInactive() { this.visible = true; } hide() { this.visible = false; } isVisible() { return this.visible; }
  isDestroyed() { return this.destroyed; } destroy() { this.destroyed = true; this.visible = false; } setAlwaysOnTop(v, l) { this.alwaysOnTop = [v, l]; } setMenu() {} moveTop() {} focus() {} isMinimized() { return false; } restore() {}
  setBounds(b) { Object.assign(this.bounds, b); } getBounds() { return { ...this.bounds }; } getSize() { return [this.bounds.width, this.bounds.height]; } getPosition() { return [this.bounds.x, this.bounds.y]; }
  close() { const ev = { prevented: false, preventDefault() { this.prevented = true; } }; this.emit('close', ev); if (!ev.prevented) this.destroy(); return ev; }
}
export class Notification extends EventEmitter { static isSupported() { return true; } constructor(o) { super(); this.o = o; } show() { rec.toasts.push(this); this.emit('show'); } close() {} }
export class Tray extends EventEmitter { setToolTip(t) { this.tip = t; } setContextMenu(m) { rec.trayMenus.push(m); } displayBalloon(b) { rec.balloons.push(b); } }
export const app = Object.assign(new EventEmitter(), { isPackaged: false, setAppUserModelId(id) { rec.aumid = id; }, requestSingleInstanceLock: () => true, whenReady: () => Promise.resolve(), getPath: () => userData, getVersion: () => '0.3.0',
  setLoginItemSettings(s) { rec.loginItems.push(s); }, quit() { this.emit('before-quit'); this.emit('will-quit'); rec.quit = true; }, exit(c) { rec.exit = c; } });
export const Menu = { buildFromTemplate: (t) => t, setApplicationMenu() {} };
export const nativeImage = { createFromPath: (p) => ({ p }) };
export const ipcMain = { handle: (c, f) => { rec.ipc[c] = f; } };
export const powerMonitor = new EventEmitter();
export const shell = { openExternal() {} };
export const dialog = { showErrorBox(t, m) { rec.error = [t, m]; } };
export const screen = { getPrimaryDisplay: () => ({ workArea: { x: 0, y: 0, width: 1920, height: 1040 } }), getDisplayNearestPoint: () => ({ workArea: { x: 0, y: 0, width: 1920, height: 1040 } }), getCursorScreenPoint: () => rec.cursor };
