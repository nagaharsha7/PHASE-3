import assert from 'node:assert/strict';
import * as electron from 'electron';
const { rec, powerMonitor } = electron;
process.env.TASKBUDDY_HIDE_MS = process.env.TASKBUDDY_HIDE_MS || '15000';
await import('../../electron/main.js'); await new Promise((r) => setTimeout(r, 200));
const dash = rec.windows[0], dws = dash.webContents, call = (c, ...a) => rec.ipc[c]({ sender: dws }, ...a);
assert.equal(rec.aumid, process.execPath); assert.ok(rec.trayMenus.length >= 1);
// first run: dashboard hands over legacy data -> migrated into SQLite. One task due right now.
const now = new Date(), hhmm = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
const task = { id: 'w', name: 'Drink Water', description: 'Stay hydrated', type: 'specific', times: [hhmm], days: [0,1,2,3,4,5,6], date: '', quantity: 250, unit: 'ml', dailyTarget: 3500, notify: true, character: true, sound: true, paused: false, scheduleFrom: 0, intervalMinutes: 60, start: '08:00', end: '22:00' };
const st = await call('tb:boot', { version: 2, tasks: [task], logs: {}, settings: { snoozeMinutes: 5 } });
assert.equal(st.tasks[0].id, 'w'); assert.equal(st.settings.snoozeMinutes, 5);
console.log('toasts after boot:', rec.toasts.length, '| title:', JSON.stringify(rec.toasts[0]?.o.title), '| body:', JSON.stringify(rec.toasts[0]?.o.body), '| silent:', rec.toasts[0]?.o.silent);
assert.equal(rec.toasts.length, 1); assert.equal(rec.toasts[0].o.silent, false);
const ch = rec.windows.find((w) => w !== dash); assert.ok(ch, 'character window created'); assert.equal(ch.visible, true);
assert.deepEqual(ch.alwaysOnTop, [true, 'screen-saver']); assert.equal(ch.o.transparent, true); assert.equal(ch.o.frame, false); assert.equal(ch.o.skipTaskbar, true); assert.equal(ch.o.webPreferences.contextIsolation, true); assert.equal(ch.o.webPreferences.nodeIntegration, false);
assert.deepEqual([ch.bounds.x, ch.bounds.y], [1920 - 330 - 16, 1040 - 430 - 16]); // bottom-right default
await rec.ipc['ch:ready']({ sender: ch.webContents });
const shown = ch.webContents.sent.filter(([c]) => c === 'ch:show').at(-1)[1]; console.log('character payload:', JSON.stringify(shown));
assert.equal(shown.taskName, 'Drink Water'); assert.equal(shown.quantity, 250);
// answers from a foreign sender are rejected
assert.equal((await rec.ipc['ch:answer']({ sender: dws }, { id: shown.id, status: 'completed' })).ok, false);
// ticking again never duplicates the toast
for (let i = 0; i < 3; i++) await new Promise((r) => setTimeout(r, 10)); assert.equal(rec.toasts.length, 1);
// YES from the character
const res = await rec.ipc['ch:answer']({ sender: ch.webContents }, { id: shown.id, status: 'completed' }); console.log('answer result:', JSON.stringify(res));
assert.equal(res.ok, true); assert.equal(res.quantity, 250);
assert.equal((await rec.ipc['ch:answer']({ sender: ch.webContents }, { id: shown.id, status: 'not_completed' })).ok, false); // double answer rejected
const pushed = dws.sent.filter(([c]) => c === 'tb:state').at(-1)[1]; assert.equal(pushed.logs[shown.id].status, 'completed'); assert.equal(pushed.summaries[pushed.logs[shown.id].date].completed, 1);
// toast click opens the character (after being dismissed)
await rec.ipc['ch:close']({ sender: ch.webContents }); assert.equal(ch.visible, false);
// dragging remembers position
ch.bounds.x = 400; ch.bounds.y = 300; ch.emit('moved');
// close dashboard -> hides to tray, app keeps running; balloon shown once
const ev = dash.close(); assert.equal(ev.prevented, true); assert.equal(dash.visible, false); assert.equal(rec.balloons.length, 1); dash.close(); assert.equal(rec.balloons.length, 1);
// tray menu
const menu = rec.trayMenus.at(-1); console.log('tray:', menu.map((m) => m.label || '---').join(' | '));
assert.deepEqual(menu.filter((m) => m.label).map((m) => m.label), ['Open TaskBuddy', 'Show Character', 'Pause All Reminders', 'Resume All Reminders', 'Settings', 'Exit TaskBuddy']);
menu.find((m) => m.label === 'Pause All Reminders').click(); assert.equal(rec.trayMenus.at(-1).find((m) => m.label === 'Resume All Reminders').enabled, true);
menu.find((m) => m.label === 'Resume All Reminders').click();
menu.find((m) => m.label === 'Settings').click(); assert.equal(dash.visible, true); assert.deepEqual(dws.sent.at(-1), ['tb:navigate', '/settings']);
menu.find((m) => m.label === 'Show Character').click(); assert.equal(ch.visible, true); // idle character, nothing pending
// settings: disable character -> hides; launch at startup only registers in packaged builds
await call('tb:action', 'setSettings', { character: false }); assert.equal(ch.visible, false);
// dashboard test button
await call('tb:action', 'setSettings', { character: true }); const t = await call('tb:test'); assert.equal(t.toast, true); assert.equal(rec.toasts.length, 2);
// sleep/wake event triggers a tick without error
powerMonitor.emit('resume'); await new Promise((r) => setTimeout(r, 1700));
// exit really quits
menu.find((m) => m.label === 'Exit TaskBuddy').click(); assert.equal(rec.quit, true); const ev2 = dash.close(); assert.equal(ev2.prevented, false);
console.log('WIRING TEST 1 OK'); process.exit(0);
