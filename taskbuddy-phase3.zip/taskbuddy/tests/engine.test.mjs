import test from 'node:test';
import assert from 'node:assert/strict';
import { reconcile, applyResponse, buildSummaries, slotDate } from '../src/lib/engine.js';
import { slotsFor } from '../src/lib/schedule.js';
import { quantityOn } from '../src/lib/stats.js';

const S = { graceMinutes: 15, snoozeMinutes: 10, quietEnabled: false, quietStart: '23:00', quietEnd: '07:00' };
const at = (h, m = 0, d = 2) => new Date(2026, 10, d, h, m, 0);
const task = (o = {}) => ({ id: 'water', name: 'Drink Water', type: 'interval', intervalMinutes: 60, start: '08:00', end: '22:00', times: [], days: [0, 1, 2, 3, 4, 5, 6], date: '', quantity: 250, unit: 'ml', paused: false, scheduleFrom: at(0).getTime(), ...o });
const ids = (logs, st) => Object.values(logs).filter((l) => !st || l.status === st).map((l) => l.scheduledTime).sort();

test('1. one-hour reminders: 8..22 = 15 slots; 10:00 is pending, earlier ones past grace are missed', () => {
  assert.equal(slotsFor(task(), '2026-11-02').length, 15);
  const r = reconcile([task()], {}, S, at(10, 0));
  assert.deepEqual(ids(r.logs), ['08:00', '09:00', '10:00']);
  assert.deepEqual(ids(r.logs, 'pending'), ['10:00']);
  assert.deepEqual(ids(r.logs, 'missed'), ['08:00', '09:00']);
});
test('2. thirty-minute reminders', () => {
  const t = task({ intervalMinutes: 30, end: '10:00' });
  assert.deepEqual(slotsFor(t, '2026-11-02'), ['08:00', '08:30', '09:00', '09:30', '10:00']);
  assert.equal(Object.keys(reconcile([t], {}, S, at(9, 0)).logs).length, 3);
});
test('3. multiple simultaneous tasks (interval + specific + daily + one-time)', () => {
  const ts = [task(), task({ id: 'pill', name: 'Pill', type: 'specific', times: ['09:00', '21:00'] }), task({ id: 'walk', name: 'Walk', type: 'daily', times: ['09:00'] }), task({ id: 'once', name: 'Call', type: 'one_time', date: '2026-11-02', times: ['09:00'] })];
  const r = reconcile(ts, {}, S, at(9, 0));
  assert.equal(Object.values(r.logs).filter((l) => l.scheduledTime === '09:00' && l.status === 'pending').length, 4);
  assert.equal(Object.keys(r.logs).filter((k) => k.startsWith('once')).length, 1);
});
test('4+5. YES adds quantity, NO adds none', () => {
  let { logs } = reconcile([task()], {}, S, at(9, 5));
  const yes = 'water|2026-11-02|09:00';
  logs = applyResponse(logs, yes, 'completed', task(), S, at(9, 6));
  assert.equal(logs[yes].responseTime, '09:06'); assert.equal(quantityOn(logs, 'water', '2026-11-02'), 250);
  const r2 = reconcile([task()], logs, S, at(10, 5)); logs = applyResponse(r2.logs, 'water|2026-11-02|10:00', 'not_completed', task(), S, at(10, 6));
  assert.equal(logs['water|2026-11-02|10:00'].quantity, 0); assert.equal(quantityOn(logs, 'water', '2026-11-02'), 250);
});
test('4b. four YES answers given as each reminder fires = 1000 ml', () => {
  let logs = {};
  for (const h of [8, 9, 10, 11]) { logs = reconcile([task()], logs, S, at(h, 0)).logs; logs = applyResponse(logs, `water|2026-11-02|${String(h).padStart(2, '0')}:00`, 'completed', task(), S, at(h, 1)); }
  assert.equal(quantityOn(logs, 'water', '2026-11-02'), 1000);
});
test('6. ignored reminder becomes missed after grace, never completed', () => {
  let { logs } = reconcile([task()], {}, S, at(8, 10)); assert.equal(logs['water|2026-11-02|08:00'].status, 'pending');
  logs = reconcile([task()], logs, S, at(8, 16)).logs; assert.equal(logs['water|2026-11-02|08:00'].status, 'missed');
  assert.equal(quantityOn(logs, 'water', '2026-11-02'), 0);
});
test('7. snooze: stays snoozed, re-prompts after duration, can then be answered', () => {
  let { logs } = reconcile([task()], {}, S, at(8, 1)); const id = 'water|2026-11-02|08:00';
  logs = applyResponse(logs, id, 'snoozed', task(), S, at(8, 2));
  assert.equal(reconcile([task()], logs, S, at(8, 11)).logs[id].status, 'snoozed');
  logs = reconcile([task()], logs, S, at(8, 13)).logs; assert.equal(logs[id].status, 'pending');
  logs = applyResponse(logs, id, 'completed', task(), S, at(8, 14)); assert.equal(logs[id].status, 'completed');
});
test('8+9. midnight: new summary, today resets, history preserved', () => {
  let { logs } = reconcile([task()], {}, S, at(22, 0));
  logs = applyResponse(logs, 'water|2026-11-02|22:00', 'completed', task(), S, at(22, 1));
  const before = buildSummaries(logs, at(23, 59))['2026-11-02'];
  logs = reconcile([task()], logs, S, at(0, 5, 3)).logs;
  const sums = buildSummaries(logs, at(0, 5, 3));
  assert.equal(sums['2026-11-02'].byTask.water.quantity, 250); assert.deepEqual(sums['2026-11-02'], before.pending ? sums['2026-11-02'] : before);
  assert.equal(sums['2026-11-03'].completed, 0); assert.equal(Object.keys(logs).filter((k) => k.includes('2026-11-02')).length >= 1, true);
});
test('9b. deleting a task keeps its history', () => {
  const { logs } = reconcile([task()], {}, S, at(9, 0));
  const after = reconcile([], logs, S, at(12, 0)).logs;
  assert.equal(Object.keys(after).length, Object.keys(logs).length);
});
test('10. duplicates and double counting prevented', () => {
  const a = reconcile([task()], {}, S, at(9, 0)); const b = reconcile([task()], a.logs, S, at(9, 0));
  assert.equal(b.changed, false); assert.equal(Object.keys(b.logs).length, Object.keys(a.logs).length);
  const id = 'water|2026-11-02|09:00';
  const once = applyResponse(a.logs, id, 'completed', task(), S, at(9, 1)); const twice = applyResponse(once, id, 'completed', task(), S, at(9, 2));
  assert.equal(quantityOn(twice, 'water', '2026-11-02'), 250); assert.equal(twice, once);
});
test('11. pausing and editing the schedule', () => {
  assert.equal(Object.keys(reconcile([task({ paused: true })], {}, S, at(12, 0)).logs).length, 0);
  const edited = task({ scheduleFrom: at(10, 30).getTime() });
  assert.deepEqual(ids(reconcile([edited], {}, S, at(12, 0)).logs), ['11:00', '12:00']);
});
test('12. wake after hours: past-grace slots recorded as missed, only in-grace slot prompts; quiet hours skipped', () => {
  const r = reconcile([task()], {}, S, at(14, 5));
  assert.deepEqual(ids(r.logs, 'pending'), ['14:00']); assert.equal(ids(r.logs, 'missed').length, 6);
  const q = reconcile([task({ end: '23:00' })], {}, { ...S, quietEnabled: true }, at(23, 0));
  assert.equal(ids(q.logs).includes('23:00'), false);
});
