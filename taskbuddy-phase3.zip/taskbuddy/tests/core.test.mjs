import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Core } from '../electron/core.js';
import { openDatabase } from '../electron/db.js';
import { notificationText } from '../electron/messages.js';
import { quantityOn } from '../src/lib/stats.js';

const at = (h, m = 0, s = 0, d = 2) => new Date(2026, 10, d, h, m, s);
const water = (o = {}) => ({ id: 'water', name: 'Drink Water', description: 'Stay hydrated', type: 'interval', intervalMinutes: 60, start: '08:00', end: '22:00', times: [], days: [0, 1, 2, 3, 4, 5, 6], date: '', quantity: 250, unit: 'ml', dailyTarget: 3500, notify: true, paused: false, scheduleFrom: at(0).getTime(), ...o });
const tmp = () => path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'tb-')), 'test.db');
function make(file = tmp(), t = at(7, 59), legacy) {
  const clock = { now: t }; const db = openDatabase(file);
  const core = new Core({ db, clock: () => clock.now }); const due = [];
  core.on('due', (l) => due.push(...l));
  core.boot(legacy || { version: 2, tasks: [water()], logs: {}, settings: {} });
  return { core, db, clock, due, file };
}

test('db driver loads and schema exists', () => { const { db } = make(); assert.match(db.driver, /sqlite/); assert.ok(db.raw.prepare("SELECT name FROM sqlite_master WHERE name='reminder_logs'").get()); });

test('8:00 creates ONE reminder, announced once; repeated ticks do not duplicate', () => {
  const { core, clock, due } = make();
  core.tick(); assert.equal(due.length, 0);
  clock.now = at(8, 0, 2); core.tick(); core.tick(); core.tick();
  assert.equal(due.length, 1); assert.equal(due[0].id, 'water|2026-11-02|08:00');
  assert.equal(Object.keys(core.state.logs).length, 1);
});

test('YES adds 250 ml once; second YES / NO afterwards cannot double count or flip it', () => {
  const { core, clock } = make(); clock.now = at(8, 0, 5); core.tick();
  const id = 'water|2026-11-02|08:00';
  assert.equal(core.respond(id, 'completed').ok, true);
  assert.equal(core.respond(id, 'completed').ok, false);
  assert.equal(core.respond(id, 'not_completed').ok, false);
  assert.equal(quantityOn(core.state.logs, 'water', '2026-11-02'), 250);
  assert.equal(core.state.logs[id].status, 'completed'); assert.ok(core.state.logs[id].responseTime);
  assert.equal(core.state.summaries['2026-11-02'].completed, 1);
});

test('NO records not_completed with 0 quantity', () => {
  const { core, clock } = make(); clock.now = at(8, 0, 5); core.tick();
  core.respond('water|2026-11-02|08:00', 'not_completed');
  assert.equal(quantityOn(core.state.logs, 'water', '2026-11-02'), 0);
  assert.equal(core.state.logs['water|2026-11-02|08:00'].status, 'not_completed');
});

test('ignored: stays pending inside grace, becomes missed after grace, never completed', () => {
  const { core, clock } = make(); clock.now = at(8, 0, 5); core.tick();
  clock.now = at(8, 14, 0); core.tick(); assert.equal(core.state.logs['water|2026-11-02|08:00'].status, 'pending');
  clock.now = at(8, 16, 0); core.tick(); assert.equal(core.state.logs['water|2026-11-02|08:00'].status, 'missed');
  assert.equal(core.respond('water|2026-11-02|08:00', 'completed').ok, false);
  assert.equal(quantityOn(core.state.logs, 'water', '2026-11-02'), 0);
});

test('snooze: re-announced once after snoozeMinutes, not before', () => {
  const { core, clock, due } = make(); clock.now = at(8, 0, 5); core.tick();
  core.respond('water|2026-11-02|08:00', 'snoozed'); assert.equal(core.state.logs['water|2026-11-02|08:00'].status, 'snoozed');
  clock.now = at(8, 9, 0); core.tick(); assert.equal(due.length, 1);
  clock.now = at(8, 10, 30); core.tick(); core.tick(); assert.equal(due.length, 2); assert.equal(core.state.logs['water|2026-11-02|08:00'].status, 'pending');
});

test('sleep/wake: waking 3 hours later gives ONE prompt, earlier slots are recorded missed, no flood', () => {
  const { core, clock, due } = make(); clock.now = at(8, 0, 5); core.tick(); due.length = 0;
  clock.now = at(11, 5, 0); core.tick();
  assert.equal(due.length, 1); assert.equal(due[0].scheduledTime, '11:00');
  const st = Object.values(core.state.logs).reduce((a, l) => ({ ...a, [l.status]: (a[l.status] || 0) + 1 }), {});
  assert.deepEqual(st, { missed: 3, pending: 1 });
});

test('multiple tasks due together are all announced once', () => {
  const t2 = water({ id: 'pill', name: 'Pill', type: 'specific', times: ['08:00'], quantity: 0 });
  const { core, clock, due } = make(tmp(), at(7, 59), { version: 2, tasks: [water(), t2], logs: {}, settings: {} });
  clock.now = at(8, 0, 3); core.tick(); core.tick();
  assert.deepEqual(due.map((l) => l.taskId).sort(), ['pill', 'water']); assert.equal(core.pendingQueue().length, 2);
});

test('paused task and "pause all" create nothing; resuming does not back-fill missed reminders', () => {
  const { core, clock, due } = make(); core.dispatch('setPausedAll', true);
  clock.now = at(10, 0, 5); core.tick(); assert.equal(due.length, 0); assert.equal(Object.keys(core.state.logs).length, 0);
  core.dispatch('setPausedAll', false); assert.equal(Object.keys(core.state.logs).length, 0);
  clock.now = at(11, 0, 5); core.tick(); assert.equal(due.length, 1);
  core.dispatch('togglePause', 'water'); clock.now = at(12, 0, 5); core.tick(); assert.equal(due.length, 1);
});

test('persistence: restart keeps tasks/logs/settings; pending-in-grace is re-announced once; answered stays answered', () => {
  const a = make(); a.clock.now = at(8, 0, 5); a.core.tick(); a.core.respond('water|2026-11-02|08:00', 'completed');
  a.clock.now = at(9, 0, 5); a.core.tick(); a.core.dispatch('setSettings', { snoozeMinutes: 5, bogus: 1 }); a.db.close();
  const b = make(a.file, at(9, 3, 0), null); // fresh process, same DB file
  assert.equal(b.core.state.settings.snoozeMinutes, 5); assert.equal(b.core.state.settings.bogus, undefined);
  assert.equal(b.core.state.logs['water|2026-11-02|08:00'].status, 'completed');
  assert.equal(b.core.state.logs['water|2026-11-02|09:00'].status, 'pending');
  assert.equal(b.due.length, 1); b.core.tick(); assert.equal(b.due.length, 1);
});

test('legacy localStorage data is migrated once, then SQLite is the source of truth', () => {
  const legacy = { version: 2, tasks: [water({ id: 'old', name: 'Old task' })], logs: { 'old|2026-11-01|09:00': { id: 'old|2026-11-01|09:00', taskId: 'old', taskName: 'Old task', date: '2026-11-01', scheduledTime: '09:00', scheduledAt: 1, dueAt: 1, responseTime: '09:01', status: 'completed', quantity: 250, unit: 'ml', snoozeUntil: null, snoozeCount: 0 } }, settings: { snoozeMinutes: 7 } };
  const a = make(tmp(), at(7, 0), legacy); assert.equal(a.core.state.tasks[0].id, 'old'); assert.equal(a.core.state.logs['old|2026-11-01|09:00'].quantity, 250); assert.equal(a.core.state.settings.snoozeMinutes, 7);
  a.db.close(); const b = make(a.file, at(7, 0), { version: 2, tasks: [water({ id: 'other' })], logs: {}, settings: {} });
  assert.equal(b.core.state.tasks[0].id, 'old'); // second boot ignores legacy data
});

test('database refuses to change a finalised reminder (raw SQL cannot double count either)', () => {
  const { core, clock, db } = make(); clock.now = at(8, 0, 5); core.tick(); core.respond('water|2026-11-02|08:00', 'completed');
  assert.throws(() => db.raw.prepare("UPDATE reminder_logs SET status='not_completed' WHERE id=?").run('water|2026-11-02|08:00'), /finalised/);
  assert.throws(() => db.raw.prepare("INSERT INTO reminder_logs (id,task_id,task_name,date,scheduled_time,scheduled_at,due_at,status) VALUES ('x','water','n','2026-11-02','08:00',1,1,'pending')").run(), /UNIQUE/);
  assert.equal(db.raw.prepare('SELECT COUNT(*) c FROM reminder_logs').get().c, 1);
});

test('backup import replaces data; character position persists in character_settings', () => {
  const { core, db } = make(); core.dispatch('importAll', { version: 2, tasks: [water({ id: 'z', name: 'Z' })], logs: {}, settings: {} });
  assert.equal(db.load().tasks[0].id, 'z'); db.setCharacter('position', { x: 10, y: 20 }); assert.deepEqual(db.getCharacter('position'), { x: 10, y: 20 });
  assert.throws(() => core.dispatch('nope'), /Unknown action/);
});

test('notification text includes task, description and quantity', () => {
  const n = notificationText({ taskName: 'Drink Water', quantity: 250, unit: 'ml' }, { description: 'x' });
  assert.equal(n.title, 'TASKBUDDY 💧'); assert.match(n.body, /Time to drink water!/); assert.match(n.body, /250 ml/);
  const g = notificationText({ taskName: 'Stretch', quantity: 0 }, { description: 'Neck and back' });
  assert.match(g.body, /Stretch/); assert.match(g.body, /Neck and back/);
});

test('dashboard actions go through dispatch and always return the full state', () => {
  const { core, clock } = make(); clock.now = at(8, 0, 5); core.tick();
  const st = core.dispatch('respond', { id: 'water|2026-11-02|08:00', status: 'completed' });
  assert.ok(st.tasks && st.logs && st.settings); assert.equal(st.logs['water|2026-11-02|08:00'].status, 'completed');
  const again = core.dispatch('respond', { id: 'water|2026-11-02|08:00', status: 'completed' }); assert.equal(quantityOn(again.logs, 'water', '2026-11-02'), 250);
  core.dispatch('saveTask', water({ id: 'new', name: 'Stretch' })); assert.equal(core.state.tasks.length, 2);
  assert.throws(() => core.dispatch('saveTask', { nope: 1 }), /Invalid task/);
  core.dispatch('deleteTask', 'new'); assert.equal(core.state.tasks.length, 1);
});
