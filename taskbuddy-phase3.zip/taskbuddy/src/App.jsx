import React, { useEffect } from 'react';
import { NavLink, Route, Routes, Navigate, useNavigate } from 'react-router-dom';
import { useStore } from './lib/store.jsx';
import WaterDrop from './components/WaterDrop.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Tasks from './pages/Tasks.jsx';
import TaskForm from './pages/TaskForm.jsx';
import History from './pages/History.jsx';
import Analytics from './pages/Analytics.jsx';
import Settings from './pages/Settings.jsx';
import ReminderPrompt from './components/ReminderPrompt.jsx';

const NAV = [['/', 'Dashboard'], ['/tasks', 'My Tasks'], ['/tasks/new', 'Add New Task'], ['/history', 'History'], ['/analytics', 'Analytics'], ['/settings', 'Settings']];
export default function App() {
  const { settings, setSettings, isDesktop } = useStore();
  const navigate = useNavigate();
  useEffect(() => (isDesktop ? window.taskbuddy.onNavigate((to) => navigate(to)) : undefined), [isDesktop, navigate]); // tray > Settings
  const dark = settings.theme === 'dark';
  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <aside className="flex shrink-0 flex-row items-center gap-2 overflow-x-auto bg-ink-900 p-3 text-ink-100 md:sticky md:top-0 md:h-screen md:w-60 md:flex-col md:items-stretch md:gap-1 md:p-4">
        <div className="mr-2 flex items-center gap-2 md:mb-6 md:mr-0"><WaterDrop size={36} mood="idle" /><span className="font-display text-lg font-semibold">TaskBuddy</span></div>
        <nav className="flex gap-1 md:flex-col">
          {NAV.map(([to, label]) => (
            <NavLink key={to} to={to} end className={({ isActive }) => `whitespace-nowrap rounded-xl px-3 py-2 text-sm transition ${isActive ? 'bg-drop-600 text-white' : 'text-ink-200 hover:bg-ink-800'}`}>{label}</NavLink>
          ))}
        </nav>
        <button className="ml-auto rounded-xl px-3 py-2 text-left text-sm text-ink-200 hover:bg-ink-800 md:ml-0 md:mt-auto" onClick={() => setSettings({ theme: dark ? 'light' : 'dark' })}>{dark ? 'Switch to light' : 'Switch to dark'}</button>
      </aside>
      <main className="min-w-0 flex-1">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/tasks" element={<Tasks />} />
          <Route path="/tasks/new" element={<TaskForm />} />
          <Route path="/tasks/:id/edit" element={<TaskForm />} />
          <Route path="/history" element={<History />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>
      {(!isDesktop || !settings.character) && <ReminderPrompt />}
    </div>
  );
}
