import React from 'react';
export const Page = ({ title, subtitle, action, children }) => (
  <div className="mx-auto max-w-6xl p-4 sm:p-8">
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div><h1 className="font-display text-3xl font-semibold tracking-tight">{title}</h1>{subtitle && <p className="muted mt-1">{subtitle}</p>}</div>{action}
    </div>{children}
  </div>
);
export const Stat = ({ label, value, hint }) => (
  <div className="card"><p className="muted">{label}</p><p className="mt-1 font-display text-3xl font-semibold tabular-nums">{value}</p>{hint && <p className="muted mt-1">{hint}</p>}</div>
);
export const Progress = ({ value }) => (
  <div className="h-3 overflow-hidden rounded-full bg-ink-100 dark:bg-ink-800" role="progressbar" aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={100}>
    <div className="h-full rounded-full bg-drop-500 transition-all duration-500" style={{ width: `${Math.min(100, value)}%` }} />
  </div>
);
const STATUS = { completed: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300', not_completed: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300', missed: 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300', snoozed: 'bg-violet-100 text-violet-800 dark:bg-violet-950 dark:text-violet-300', pending: 'bg-ink-100 text-ink-700 dark:bg-ink-800 dark:text-ink-200' };
export const Badge = ({ status }) => <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${STATUS[status]}`}>{status.replace('_', ' ')}</span>;
