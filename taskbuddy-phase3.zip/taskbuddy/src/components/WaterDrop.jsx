import React from 'react';
// Reusable character. Future characters implement the same props: { mood, size }.
const MOODS = { idle: 'animate-bob', happy: 'animate-bob', sad: '', thinking: 'animate-sway', waving: 'animate-bob' };
export default function WaterDrop({ mood = 'idle', size = 96 }) {
  const mouth = { idle: 'M40 62 Q50 70 60 62', happy: 'M38 60 Q50 76 62 60 Z', sad: 'M41 68 Q50 60 59 68', thinking: 'M43 66 L57 64', waving: 'M38 60 Q50 76 62 60 Z' }[mood];
  return (
    <div className={MOODS[mood]} style={{ width: size, height: size }} role="img" aria-label={`Water drop buddy, ${mood}`}>
      <svg viewBox="0 0 100 100" width="100%" height="100%">
        <defs><linearGradient id="dg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#7dd3fc" /><stop offset="1" stopColor="#0284c7" /></linearGradient></defs>
        <path d="M50 6 C50 6 18 44 18 66 A32 30 0 0 0 82 66 C82 44 50 6 50 6Z" fill="url(#dg)" />
        <ellipse cx="34" cy="52" rx="5" ry="10" fill="#fff" opacity=".35" transform="rotate(18 34 52)" />
        <g fill="#0b1b2b"><circle cx="40" cy="50" r="4.5" /><circle cx="60" cy="50" r="4.5" /></g>
        <g fill="#fff"><circle cx="41.5" cy="48.5" r="1.5" /><circle cx="61.5" cy="48.5" r="1.5" /></g>
        {mood === 'thinking' && <path d="M52 42 L66 38" stroke="#0b1b2b" strokeWidth="2" strokeLinecap="round" />}
        <path d={mouth} fill={mood === 'happy' || mood === 'waving' ? '#7f1d1d' : 'none'} stroke="#0b1b2b" strokeWidth="2.5" strokeLinecap="round" />
        {mood === 'sad' && <path d="M66 58 q3 6 0 8 q-3 -2 0 -8Z" fill="#bae6fd" />}
        <g className={mood === 'waving' ? 'animate-wave' : ''} style={{ transformOrigin: '82px 62px' }}><path d="M82 62 L94 48" stroke="#0284c7" strokeWidth="5" strokeLinecap="round" /></g>
        <path d="M18 62 L7 72" stroke="#0284c7" strokeWidth="5" strokeLinecap="round" />
      </svg>
    </div>
  );
}
