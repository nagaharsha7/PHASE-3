import React, { useEffect, useState } from 'react';
import { useStore } from '../lib/store.jsx';
import WaterDrop from './WaterDrop.jsx';
import { to12 } from '../lib/schedule.js';

// In-page reminder. Only visible while TaskBuddy is open in the browser.
export default function ReminderPrompt() {
  const { logs, tasks, settings, respond } = useStore();
  const [fb, setFb] = useState(null);
  useEffect(() => { if (!fb) return; const t = setTimeout(() => setFb(null), 2500); return () => clearTimeout(t); }, [fb]);
  const pending = Object.values(logs).filter((l) => l.status === 'pending' && tasks.find((t) => t.id === l.taskId)?.notify !== false).sort((a, b) => a.dueAt - b.dueAt);
  if (!settings.notifications || (!pending.length && !fb)) return null;
  const cur = pending[0], task = cur && tasks.find((t) => t.id === cur.taskId);
  const answer = (status) => { respond(cur.id, status); setFb(status === 'completed' ? { m: `Awesome! I've recorded ${cur.quantity || task?.quantity || ''} ${task?.unit || ''}.`, mood: 'happy' } : status === 'not_completed' ? { m: "No problem! I've noted that.", mood: 'sad' } : { m: `Okay, I'll ask again in ${settings.snoozeMinutes} min.`, mood: 'thinking' }); };
  return (
    <div role="alertdialog" aria-live="polite" aria-label="Reminder" className="fixed bottom-4 right-4 z-50 w-[calc(100vw-2rem)] max-w-sm rounded-2xl bg-white p-4 shadow-xl ring-1 ring-ink-200 dark:bg-ink-900 dark:ring-ink-700" style={{ marginBottom: 'env(safe-area-inset-bottom, 0px)' }}>
      <div className="flex items-center gap-3">
        <WaterDrop mood={cur ? 'waving' : fb.mood} size={72} />
        <div className="min-w-0 flex-1">
          {cur ? (<><p className="font-display font-semibold">Did you complete your task?</p>
            <p className="muted truncate">{cur.taskName}{task?.quantity ? ` · ${task.quantity} ${task.unit}` : ''} · due {to12(cur.scheduledTime)}</p>
            {pending.length > 1 && <p className="muted">+{pending.length - 1} more waiting</p>}</>) : <p className="font-medium">{fb.m}</p>}
        </div>
      </div>
      {cur && <div className="mt-3 flex gap-2"><button className="btn-primary flex-1" onClick={() => answer('completed')}>Yes</button><button className="btn-ghost flex-1" onClick={() => answer('not_completed')}>No</button><button className="btn-ghost" onClick={() => answer('snoozed')}>Snooze</button></div>}
      {cur && fb && <p className="muted mt-2">{fb.m}</p>}
    </div>
  );
}
