import React from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../lib/store.jsx';
import { Page } from '../components/ui.jsx';
import { TYPES, intervalLabel, to12, DAYS } from '../lib/schedule.js';

const describe = (t) => t.type === 'interval' ? `Every ${intervalLabel(t.intervalMinutes)}, ${to12(t.start)} to ${to12(t.end)}` : t.type === 'one_time' ? `${t.date} at ${to12(t.times[0] || '09:00')}` : `At ${t.times.map(to12).join(', ')}`;
export default function Tasks() {
  const { tasks, togglePause, deleteTask } = useStore();
  return (
    <Page title="My Tasks" subtitle={`${tasks.length} task${tasks.length === 1 ? '' : 's'}`} action={<Link to="/tasks/new" className="btn-primary">Add task</Link>}>
      {!tasks.length && <div className="card"><p className="muted">No tasks yet. Add your first one to get started.</p></div>}
      <div className="grid gap-4 md:grid-cols-2">
        {tasks.map((t) => (
          <div key={t.id} className={`card ${t.paused ? 'opacity-70' : ''}`}>
            <div className="flex items-start justify-between gap-2">
              <div><h3 className="font-display text-lg font-semibold">{t.name}</h3><p className="muted">{t.category} · {TYPES[t.type]}</p></div>
              <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${t.paused ? 'bg-ink-100 text-ink-700 dark:bg-ink-800 dark:text-ink-200' : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'}`}>{t.paused ? 'Paused' : 'Active'}</span>
            </div>
            <p className="mt-3 text-sm">{describe(t)}</p>
            <p className="muted mt-1">{t.type !== 'one_time' && (t.days.length === 7 ? 'Every day' : t.days.map((d) => DAYS[d]).join(', '))}{t.quantity ? ` · ${t.quantity} ${t.unit}` : ''}{t.dailyTarget ? ` · target ${t.dailyTarget} ${t.unit}` : ''}</p>
            <div className="mt-4 flex gap-2">
              <Link to={`/tasks/${t.id}/edit`} className="btn-ghost">Edit</Link>
              <button className="btn-ghost" onClick={() => togglePause(t.id)}>{t.paused ? 'Resume' : 'Pause'}</button>
              <button className="btn-danger" onClick={() => confirm(`Delete "${t.name}"? Its history is kept.`) && deleteTask(t.id)}>Delete</button>
            </div>
          </div>))}
      </div>
    </Page>
  );
}
