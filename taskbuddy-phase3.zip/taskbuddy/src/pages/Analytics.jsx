import React, { useState } from 'react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, Legend } from 'recharts';
import { useStore } from '../lib/store.jsx';
import { lastDays, rate, streak, between, weekStart, monthStart } from '../lib/stats.js';
import { dateStr } from '../lib/schedule.js';
import { Page, Stat, Progress } from '../components/ui.jsx';

export default function Analytics() {
  const { logs, tasks } = useStore();
  const [range, setRange] = useState(7);
  const today = dateStr(), days = lastDays(range), all = Object.values(logs).filter((l) => days.includes(l.date));
  const c = (l, s) => l.filter((x) => x.status === s).length;
  const data = days.map((d) => { const l = all.filter((x) => x.date === d); return { day: d.slice(5), Completed: c(l, 'completed'), 'Not completed': c(l, 'not_completed'), Missed: c(l, 'missed') }; });
  const ids = [...new Map(all.map((l) => [l.taskId, l.taskName])).entries()];
  const totals = {}; all.filter((l) => l.status === 'completed' && l.quantity).forEach((l) => { totals[l.unit] = (totals[l.unit] || 0) + l.quantity; });
  const tick = '#5b7691';
  const week = rate(between(logs, weekStart(), today)), month = rate(between(logs, monthStart(), today));
  return (
    <Page title="Analytics" action={<select className="input w-auto" value={range} onChange={(e) => setRange(Number(e.target.value))}><option value={7}>Last 7 days</option><option value={30}>Last 30 days</option></select>}>
      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-3">
        <Stat label="Completion rate" value={`${rate(all)}%`} hint={`last ${range} days`} />
        <Stat label="This week" value={`${week}%`} hint="Monday to today" />
        <Stat label="This month" value={`${month}%`} hint="1st to today" />
        <Stat label="Day streak" value={streak(logs)} />
        <Stat label="Missed" value={c(all, 'missed')} hint={`${c(all, 'not_completed')} answered No`} />
        <Stat label="Total completed" value={Object.entries(totals).map(([u, n]) => `${n} ${u}`).join(', ') || c(all, 'completed')} />
      </div>
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="card lg:col-span-2"><h2 className="mb-3 font-display text-lg font-semibold">Reminders per day</h2>
          <div className="h-64"><ResponsiveContainer><BarChart data={data}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#c9d7e6" strokeOpacity=".4" /><XAxis dataKey="day" tick={{ fill: tick, fontSize: 12 }} /><YAxis allowDecimals={false} tick={{ fill: tick, fontSize: 12 }} /><Tooltip /><Legend /><Bar dataKey="Completed" stackId="a" fill="#0ea5e9" /><Bar dataKey="Not completed" stackId="a" fill="#f59e0b" /><Bar dataKey="Missed" stackId="a" fill="#ef4444" radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer></div></div>
        <div className="card"><h2 className="mb-3 font-display text-lg font-semibold">By task</h2>
          {!ids.length && <p className="muted">No reminders in this period yet.</p>}
          <div className="space-y-4">{ids.map(([id, name]) => <div key={id}><div className="mb-1 flex justify-between text-sm"><span>{name}</span><span className="tabular-nums">{rate(all.filter((l) => l.taskId === id))}% · {streak(logs, id)}-day streak</span></div><Progress value={rate(all.filter((l) => l.taskId === id))} /></div>)}</div></div>
      </div>
      <p className="muted mt-4">{tasks.length} task{tasks.length === 1 ? '' : 's'}. Rates count completed ÷ (completed + not completed + missed); pending reminders are excluded until decided.</p>
    </Page>
  );
}
