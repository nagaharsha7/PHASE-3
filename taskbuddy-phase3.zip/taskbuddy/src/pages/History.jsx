import React, { useState } from 'react';
import { useStore } from '../lib/store.jsx';
import { Page, Badge } from '../components/ui.jsx';
import { to12 } from '../lib/schedule.js';

export default function History() {
  const { logs } = useStore();
  const [from, setFrom] = useState(''), [to, setTo] = useState(''), [status, setStatus] = useState('');
  const rows = Object.values(logs).filter((l) => (!from || l.date >= from) && (!to || l.date <= to) && (!status || l.status === status))
    .sort((a, b) => (b.date + b.scheduledTime).localeCompare(a.date + a.scheduledTime));
  return (
    <Page title="History" subtitle={`${rows.length} record${rows.length === 1 ? '' : 's'}`}>
      <div className="card mb-4 flex flex-wrap gap-3">
        <div><label className="label">From</label><input type="date" className="input" value={from} onChange={(e) => setFrom(e.target.value)} /></div>
        <div><label className="label">To</label><input type="date" className="input" value={to} onChange={(e) => setTo(e.target.value)} /></div>
        <div><label className="label">Status</label><select className="input" value={status} onChange={(e) => setStatus(e.target.value)}><option value="">All</option>{['completed', 'not_completed', 'missed', 'pending', 'snoozed'].map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}</select></div>
      </div>
      <div className="card overflow-x-auto p-0">
        <table className="w-full text-left text-sm">
          <thead className="text-ink-500"><tr>{['Date', 'Task', 'Scheduled', 'Responded', 'Status', 'Quantity'].map((h) => <th key={h} className="px-4 py-3 font-medium">{h}</th>)}</tr></thead>
          <tbody className="divide-y divide-ink-100 dark:divide-ink-800">
            {rows.map((l) => (<tr key={l.id}><td className="px-4 py-2.5 tabular-nums">{l.date}</td><td className="px-4 py-2.5">{l.taskName}</td><td className="px-4 py-2.5 tabular-nums">{to12(l.scheduledTime)}</td><td className="px-4 py-2.5 tabular-nums">{l.responseTime ? to12(l.responseTime) : '–'}</td><td className="px-4 py-2.5"><Badge status={l.status} /></td><td className="px-4 py-2.5 tabular-nums">{l.quantity ? `${l.quantity} ${l.unit}` : '–'}</td></tr>))}
          </tbody>
        </table>
        {!rows.length && <p className="muted p-4">Nothing here yet. Answer a reminder on the Dashboard and it will show up.</p>}
      </div>
    </Page>
  );
}
