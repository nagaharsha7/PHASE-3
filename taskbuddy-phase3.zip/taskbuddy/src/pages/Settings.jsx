import React, { useEffect, useRef, useState } from 'react';
import { useStore } from '../lib/store.jsx';
import { Page } from '../components/ui.jsx';

const Row = ({ title, hint, children, disabled }) => (
  <div className={`flex items-center justify-between gap-4 py-3 ${disabled ? 'opacity-60' : ''}`}><div><p className="text-sm font-medium">{title}</p>{hint && <p className="muted">{hint}</p>}</div>{children}</div>);
const Switch = ({ checked, onChange, disabled }) => <input type="checkbox" role="switch" disabled={disabled} checked={checked} onChange={(e) => onChange(e.target.checked)} className="h-5 w-5 accent-sky-600" />;

export default function Settings() {
  const { settings: s, setSettings, exportJson, importJson, isDesktop } = useStore();
  const file = useRef(); const [msg, setMsg] = useState(''); const [info, setInfo] = useState(null);
  useEffect(() => { if (isDesktop) window.taskbuddy.getInfo().then(setInfo); }, [isDesktop]);
  const test = async () => { const r = await window.taskbuddy.sendTestReminder(); setMsg(r.toast ? 'Test sent: look for the Windows notification and the floating character.' : 'Character shown. Windows notification skipped (notifications are off or unsupported).'); };
  const D = !isDesktop; // desktop-only switches are disabled in a normal browser
  const backup = () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([exportJson()], { type: 'application/json' })); a.download = `taskbuddy-backup-${new Date().toISOString().slice(0, 10)}.json`; a.click(); setMsg('Backup downloaded.'); };
  const restore = async (e) => { try { importJson(await e.target.files[0].text()); setMsg('Backup restored.'); } catch (x) { setMsg(x.message); } e.target.value = ''; };
  return (
    <Page title="Settings">
      <div className="card divide-y divide-ink-100 py-2 dark:divide-ink-800">
        <Row title="Dark theme"><Switch checked={s.theme === 'dark'} onChange={(v) => setSettings({ theme: v ? 'dark' : 'light' })} /></Row>
        <Row title="Desktop notifications" hint={D ? 'Windows notifications need the desktop app.' : 'Native Windows notifications, even when the dashboard is closed.'}><Switch checked={s.notifications} onChange={(v) => setSettings({ notifications: v })} /></Row>
        <Row title="Animated character" hint={D ? 'The floating character needs the desktop app.' : 'A floating water drop appears on your desktop when a reminder is due.'}><Switch checked={s.character} onChange={(v) => setSettings({ character: v })} /></Row>
        <Row title="Character animations" disabled={!s.character}><Switch checked={s.characterAnimations} disabled={!s.character} onChange={(v) => setSettings({ characterAnimations: v })} /></Row>
        <Row title="Show character for every reminder" hint="Off: only tasks that have the character enabled in their own settings." disabled={!s.character}><Switch checked={s.showCharacterForEvery} disabled={!s.character} onChange={(v) => setSettings({ showCharacterForEvery: v })} /></Row>
        <Row title="Notification sound"><Switch checked={s.sound} onChange={(v) => setSettings({ sound: v })} /></Row>
        <Row title="Character size"><select className="input w-36" value={s.characterSize} onChange={(e) => setSettings({ characterSize: e.target.value })}><option value="small">Small</option><option value="medium">Medium</option><option value="large">Large</option></select></Row>
        <Row title="Character position" hint="Corner used until you drag the character; changing this resets a dragged position."><select className="input w-36" value={s.characterPosition} onChange={(e) => setSettings({ characterPosition: e.target.value })}>{['bottom-right', 'bottom-left', 'top-right', 'top-left'].map((p) => <option key={p}>{p}</option>)}</select></Row>
        <Row title="Pause all reminders" hint={D ? 'Needs the desktop app.' : 'Same as the tray menu. Resuming does not create missed reminders for the pause.'} disabled={D}><Switch disabled={D} checked={s.pausedAll} onChange={(v) => (isDesktop ? window.taskbuddy.action('setPausedAll', v) : setSettings({ pausedAll: v }))} /></Row>
        <Row title="Use quiet hours" hint="Reminders inside the window below are skipped, not recorded."><Switch checked={s.quietEnabled} onChange={(v) => setSettings({ quietEnabled: v })} /></Row>
        <Row title="Quiet hours"><div className="flex items-center gap-2"><input type="time" className="input w-32" value={s.quietStart} onChange={(e) => setSettings({ quietStart: e.target.value })} /><span className="muted">to</span><input type="time" className="input w-32" value={s.quietEnd} onChange={(e) => setSettings({ quietEnd: e.target.value })} /></div></Row>
        <Row title="Snooze duration"><div className="flex items-center gap-2"><input type="number" min="1" className="input w-20" value={s.snoozeMinutes} onChange={(e) => setSettings({ snoozeMinutes: Number(e.target.value) || 10 })} /><span className="muted">min</span></div></Row>
        <Row title="Grace period" hint="An unanswered reminder is recorded as missed after this long."><div className="flex items-center gap-2"><input type="number" min="1" className="input w-20" value={s.graceMinutes} onChange={(e) => setSettings({ graceMinutes: Number(e.target.value) || 15 })} /><span className="muted">min</span></div></Row>
        <Row title="Launch at Windows startup" hint={D ? 'Needs the desktop app.' : 'Starts TaskBuddy in the tray when you sign in to Windows (installed app only).'} disabled={D}><Switch disabled={D} checked={s.launchAtStartup} onChange={(v) => setSettings({ launchAtStartup: v })} /></Row>
        <Row title="Start minimized" hint={D ? 'Needs the desktop app.' : 'When TaskBuddy starts with Windows, stay in the tray instead of opening the dashboard.'} disabled={D}><Switch disabled={D} checked={s.startMinimized} onChange={(v) => setSettings({ startMinimized: v })} /></Row>
        <Row title="Minimize to tray" hint={D ? 'Needs the desktop app.' : 'Minimizing hides the dashboard in the tray. Closing it always keeps TaskBuddy running; use tray > Exit TaskBuddy to quit.'} disabled={D}><Switch disabled={D} checked={s.minimizeToTray} onChange={(v) => setSettings({ minimizeToTray: v })} /></Row>
      </div>
      <div className="card mt-6"><h2 className="font-display text-lg font-semibold">Backup and restore</h2><p className="muted mb-3">Saves tasks, history and settings to a JSON file. To move data from the browser version, download a backup there and restore it here.</p>
        <div className="flex gap-2"><button className="btn-primary" onClick={backup}>Download backup</button><button className="btn-ghost" onClick={() => file.current.click()}>Restore from file</button><input ref={file} type="file" accept="application/json" hidden onChange={restore} /></div>
        {msg && <p role="status" className="muted mt-3">{msg}</p>}</div>
      {isDesktop && (
        <div className="card mt-6"><h2 className="font-display text-lg font-semibold">Desktop app</h2>
          <p className="muted mb-3">Sends a real Windows notification and shows the floating character. Nothing is saved to your history.</p>
          <button className="btn-primary" onClick={test}>Send test reminder</button>
          {info && <dl className="muted mt-4 space-y-1 break-all"><div>Version {info.version} · Electron {info.electron} · {info.packaged ? 'installed build' : 'development build'}</div><div>Database ({info.sqlite}): {info.dbPath}</div><div>Log file: {info.logPath}</div>{!info.toastsSupported && <div className="text-red-600">Windows notifications are not supported on this system.</div>}</dl>}
        </div>)}
    </Page>
  );
}
