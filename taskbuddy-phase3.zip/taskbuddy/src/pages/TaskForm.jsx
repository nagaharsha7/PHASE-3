import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useStore } from '../lib/store.jsx';
import { Page } from '../components/ui.jsx';
import { TYPES, DAYS, dateStr } from '../lib/schedule.js';

const BLANK = { name: '', description: '', category: 'Health', type: 'interval', intervalMinutes: 60, start: '08:00', end: '22:00', times: ['09:00'], days: [0, 1, 2, 3, 4, 5, 6], date: dateStr(), quantity: '', unit: 'ml', dailyTarget: '', notify: true, character: true, sound: true, paused: false };
const Field = ({ label, children }) => <div><label className="label">{label}</label>{children}</div>;
const Toggle = ({ label, checked, onChange }) => <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="h-4 w-4 accent-sky-600" />{label}</label>;

export default function TaskForm() {
  const { id } = useParams(); const nav = useNavigate();
  const { tasks, saveTask } = useStore();
  const [f, setF] = useState(() => tasks.find((t) => t.id === id) || BLANK);
  const [err, setErr] = useState('');
  const set = (p) => setF((x) => ({ ...x, ...p }));
  const submit = (e) => {
    e.preventDefault();
    if (!f.name.trim()) return setErr('Give the task a name.');
    if (f.type === 'interval' && f.start >= f.end) return setErr('End time must be after start time.');
    if (f.type !== 'interval' && !f.times.length) return setErr('Add at least one reminder time.');
    if (f.type !== 'one_time' && !f.days.length) return setErr('Pick at least one day.');
    const num = (v) => (v === '' || v == null ? 0 : Number(v));
    saveTask({ ...f, id: id || `t${Date.now().toString(36)}`, name: f.name.trim(), intervalMinutes: num(f.intervalMinutes) || 60, quantity: num(f.quantity), dailyTarget: num(f.dailyTarget), times: f.type === 'daily' || f.type === 'one_time' ? f.times.slice(0, 1) : f.times });
    nav('/tasks');
  };
  const unitHours = f.intervalMinutes % 60 === 0;
  return (
    <Page title={id ? 'Edit task' : 'Add new task'} subtitle="Choose what to be reminded about and how often.">
      <form onSubmit={submit} className="grid gap-6 lg:grid-cols-2">
        <div className="card space-y-4">
          <Field label="Task name"><input className="input" value={f.name} onChange={(e) => set({ name: e.target.value })} placeholder="Drink water" /></Field>
          <Field label="Description (optional)"><input className="input" value={f.description} onChange={(e) => set({ description: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Category"><select className="input" value={f.category} onChange={(e) => set({ category: e.target.value })}>{['Health', 'Fitness', 'Work', 'Study', 'Personal'].map((c) => <option key={c}>{c}</option>)}</select></Field>
            <Field label="Reminder type"><select className="input" value={f.type} onChange={(e) => set({ type: e.target.value })}>{Object.entries(TYPES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
          </div>
          {f.type === 'interval' ? (<>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Remind every"><div className="flex gap-2"><input type="number" min="1" className="input" value={unitHours ? f.intervalMinutes / 60 : f.intervalMinutes} onChange={(e) => set({ intervalMinutes: Number(e.target.value) * (unitHours ? 60 : 1) })} />
                <select className="input w-28" value={unitHours ? 'h' : 'm'} onChange={(e) => set({ intervalMinutes: e.target.value === 'h' ? Math.max(60, Math.round(f.intervalMinutes / 60) * 60) : f.intervalMinutes })}><option value="h">hours</option><option value="m">minutes</option></select></div></Field>
              <div className="grid grid-cols-2 gap-2"><Field label="Start"><input type="time" className="input" value={f.start} onChange={(e) => set({ start: e.target.value })} /></Field><Field label="End"><input type="time" className="input" value={f.end} onChange={(e) => set({ end: e.target.value })} /></Field></div>
            </div></>) : (
            <Field label={f.type === 'specific' ? 'Reminder times' : 'Reminder time'}>
              <div className="space-y-2">{(f.type === 'specific' ? f.times : f.times.slice(0, 1)).map((t, i) => (
                <div key={i} className="flex gap-2"><input type="time" className="input" value={t} onChange={(e) => set({ times: f.times.map((x, j) => (j === i ? e.target.value : x)) })} />
                  {f.type === 'specific' && f.times.length > 1 && <button type="button" className="btn-ghost" onClick={() => set({ times: f.times.filter((_, j) => j !== i) })}>Remove</button>}</div>))}
                {f.type === 'specific' && <button type="button" className="btn-ghost" onClick={() => set({ times: [...f.times, '12:00'] })}>Add another time</button>}</div></Field>)}
          {f.type === 'one_time' ? <Field label="Date"><input type="date" className="input" value={f.date} onChange={(e) => set({ date: e.target.value })} /></Field> : (
            <Field label="Repeat on"><div className="flex flex-wrap gap-2">{DAYS.map((d, i) => { const on = f.days.includes(i); return <button type="button" key={d} aria-pressed={on} onClick={() => set({ days: on ? f.days.filter((x) => x !== i) : [...f.days, i] })} className={`rounded-xl px-3 py-1.5 text-sm ${on ? 'bg-drop-600 text-white' : 'bg-ink-100 dark:bg-ink-800'}`}>{d}</button>; })}</div></Field>)}
        </div>
        <div className="space-y-6">
          <div className="card space-y-4">
            <h2 className="font-display text-lg font-semibold">Quantity tracking</h2>
            <div className="grid grid-cols-3 gap-3">
              <Field label="Per reminder"><input type="number" min="0" className="input" value={f.quantity} onChange={(e) => set({ quantity: e.target.value })} placeholder="250" /></Field>
              <Field label="Unit"><input className="input" list="units" value={f.unit} onChange={(e) => set({ unit: e.target.value })} /><datalist id="units">{['ml', 'litres', 'minutes', 'repetitions', 'pages', 'steps'].map((u) => <option key={u} value={u} />)}</datalist></Field>
              <Field label="Daily target"><input type="number" min="0" className="input" value={f.dailyTarget} onChange={(e) => set({ dailyTarget: e.target.value })} placeholder="3500" /></Field>
            </div>
            <p className="muted">Only a Yes answer adds to the daily total.</p>
          </div>
          <div className="card space-y-3">
            <h2 className="font-display text-lg font-semibold">How to remind me</h2>
            <Toggle label="Desktop notification" checked={f.notify} onChange={(v) => set({ notify: v })} />
            <Toggle label="Show desktop character" checked={f.character} onChange={(v) => set({ character: v })} />
            <Toggle label="Play sound" checked={f.sound} onChange={(v) => set({ sound: v })} />
          </div>
          {err && <p role="alert" className="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-700 dark:bg-red-950 dark:text-red-300">{err}</p>}
          <div className="flex gap-2"><button className="btn-primary">{id ? 'Save changes' : 'Create task'}</button><button type="button" className="btn-ghost" onClick={() => nav('/tasks')}>Cancel</button></div>
        </div>
      </form>
    </Page>
  );
}
