import React from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../lib/store.jsx';
import { todayView, quantityOn, countOn } from '../lib/stats.js';
import { dateStr, to12 } from '../lib/schedule.js';
import { Page, Stat, Progress, Badge } from '../components/ui.jsx';
import WaterDrop from '../components/WaterDrop.jsx';

export default function Dashboard() {
  const { tasks, logs, settings, respond } = useStore();
  const ds = dateStr();
  const rows = todayView(tasks, logs, settings);
  const n = (st) => rows.filter((r) => r.state === st).length;
  const done = n('completed'), declined = n('not_completed'), missed = n('missed'), waiting = n('pending') + n('snoozed');
  const decided = done + declined + missed;
  const next = rows.find((r) => r.state === 'upcoming');
  const hero = tasks.find((t) => t.quantity && t.dailyTarget && !t.paused);
  const total = hero ? quantityOn(logs, hero.id, ds) : 0;
  const pct = hero ? (total / hero.dailyTarget) * 100 : 0;
  const mood = n('pending') ? 'waving' : pct >= 100 ? 'happy' : declined + missed > done && decided ? 'sad' : 'idle';
  const first = rows.find((r) => r.state === 'pending');
  const say = first ? `${first.task.name} is due. Did you do it?` : next ? `Next up: ${next.task.name} at ${to12(next.time)}.` : tasks.length ? 'Nothing left for today.' : 'Add a task and I will remind you.';

  return (
    <Page title="Today" subtitle={new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' })} action={<Link to="/tasks/new" className="btn-primary">Add task</Link>}>
      <div className="card mb-6 flex flex-col items-center gap-6 sm:flex-row">
        <WaterDrop mood={mood} size={128} />
        <div className="w-full">
          <p className="mb-3 inline-block rounded-2xl rounded-bl-sm bg-ink-100 px-4 py-2 text-sm dark:bg-ink-800">{say}</p>
          {hero ? (<>
            <div className="flex items-baseline justify-between"><p className="font-display text-4xl font-semibold tabular-nums">{total} <span className="text-lg font-normal text-ink-500">/ {hero.dailyTarget} {hero.unit}</span></p><p className="muted">{Math.round(pct)}%</p></div>
            <div className="my-3"><Progress value={pct} /></div>
            <p className="muted">{hero.name}: {Math.max(0, hero.dailyTarget - total)} {hero.unit} remaining · {countOn(logs, hero.id, ds, 'completed')} successful · {countOn(logs, hero.id, ds, 'missed')} missed</p>
          </>) : <p className="muted">Give a task a quantity and daily target to track progress here.</p>}
        </div>
      </div>
      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-5">
        <Stat label="Completed" value={done} />
        <Stat label="Not completed" value={declined} />
        <Stat label="Missed" value={missed} />
        <Stat label="Pending" value={waiting} />
        <Stat label="Completion" value={`${decided ? Math.round((done / decided) * 100) : 0}%`} hint={`${decided} answered or missed`} />
      </div>
      <div className="card">
        <h2 className="mb-3 font-display text-lg font-semibold">Today's schedule</h2>
        {!rows.length && <p className="muted">No reminders scheduled today. <Link className="text-drop-600 underline" to="/tasks/new">Create a task</Link>.</p>}
        <ul className="divide-y divide-ink-100 dark:divide-ink-800">
          {rows.map((r) => (
            <li key={r.id} className="flex flex-wrap items-center gap-3 py-2.5">
              <span className="w-20 text-sm tabular-nums text-ink-500">{to12(r.time)}</span>
              <span className="min-w-0 flex-1 truncate text-sm font-medium">{r.task.name}{r.task.quantity ? <span className="muted"> · {r.task.quantity} {r.task.unit}</span> : null}</span>
              {r.state === 'pending' ? (<>
                <button className="btn-primary px-3 py-1" onClick={() => respond(r.id, 'completed')}>Yes</button>
                <button className="btn-ghost px-3 py-1" onClick={() => respond(r.id, 'not_completed')}>No</button>
                <button className="btn-ghost px-3 py-1" onClick={() => respond(r.id, 'snoozed')}>Snooze</button>
              </>) : r.state === 'upcoming' ? <span className="muted">upcoming</span> : (<><Badge status={r.state} />{r.state === 'snoozed' && <span className="muted">until {new Date(r.log.snoozeUntil).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</span>}</>)}
            </li>))}
        </ul>
      </div>
    </Page>
  );
}
