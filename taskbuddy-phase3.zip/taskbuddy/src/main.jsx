import React from 'react';
import { createRoot } from 'react-dom/client';
import { HashRouter } from 'react-router-dom'; // HashRouter works under file:// in Electron
import App from './App.jsx';
import { StoreProvider, readLegacy } from './lib/store.jsx';
import './index.css';

const mount = (desktop) => createRoot(document.getElementById('root')).render(<HashRouter><StoreProvider desktop={desktop}><App /></StoreProvider></HashRouter>);

// Inside the Windows app `window.taskbuddy` exists (secure preload bridge). In a normal browser it does not and the web version runs unchanged.
const bridge = window.taskbuddy;
if (!bridge) mount(undefined);
else bridge.boot(readLegacy()).then((initial) => mount({ bridge, initial })); // first run: main process imports any old localStorage data into SQLite
